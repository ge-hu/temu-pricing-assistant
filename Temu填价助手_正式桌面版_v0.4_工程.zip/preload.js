const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('temuDesktop', {
  getSettings: () => ipcRenderer.invoke('desktop:get-settings'),
  getAssets: () => ipcRenderer.invoke('desktop:get-assets'),
  updateSettings: patch => ipcRenderer.invoke('desktop:update-settings', patch),
  chooseWallpaper: () => ipcRenderer.invoke('desktop:choose-wallpaper'),
  resetWallpaper: () => ipcRenderer.invoke('desktop:reset-wallpaper'),
  chooseFloatingIcon: () => ipcRenderer.invoke('desktop:choose-floating-icon'),
  resetFloatingIcon: () => ipcRenderer.invoke('desktop:reset-floating-icon'),
  toggleHistoryPanel: () => ipcRenderer.invoke('desktop:toggle-history-panel'),
  historySearch: q => ipcRenderer.invoke('desktop:history-search', q),
  historyDetail: spu => ipcRenderer.invoke('desktop:history-detail', spu),
  historyAdd: payload => ipcRenderer.invoke('desktop:history-add', payload),
  historyUpdate: payload => ipcRenderer.invoke('desktop:history-update', payload),
  getState: () => ipcRenderer.invoke('desktop:get-state'),
  getRecovery: () => ipcRenderer.invoke('desktop:get-recovery'),
  openSettings: () => ipcRenderer.invoke('desktop:open-settings'),
  toggleFloat: () => ipcRenderer.invoke('desktop:toggle-float'),
  showMain: () => ipcRenderer.invoke('desktop:show-main'),
  hideFloat: () => ipcRenderer.invoke('desktop:hide-float'),
  command: cmd => ipcRenderer.invoke('desktop:command', cmd),
  setFloatOpacity: value => ipcRenderer.invoke('desktop:set-float-opacity', value),
  exportData: () => ipcRenderer.invoke('desktop:export-data'),
  restoreData: () => ipcRenderer.invoke('desktop:restore-data'),
  backupNow: () => ipcRenderer.invoke('desktop:backup-now'),
  openBackupDir: () => ipcRenderer.invoke('desktop:open-backup-dir'),
  checkUpdates: () => ipcRenderer.invoke('desktop:check-updates'),
  onState: fn => ipcRenderer.on('desktop-state', (_e, state) => fn(state)),
  onSettingsChanged: fn => ipcRenderer.on('desktop-settings-changed', (_e, settings) => fn(settings))
});

function isMainApp() {
  return /[\\/]app[\\/]index\.html$/i.test(decodeURIComponent(location.pathname || '')) || /\/app\/index\.html$/i.test(location.pathname || '');
}
function activeTabName() {
  const active = document.querySelector('.app-tab.active');
  return active?.textContent?.trim() || '';
}
function currentStore() {
  const sf = document.getElementById('storeFilter');
  if (!sf) return '';
  const opt = sf.options?.[sf.selectedIndex];
  const raw = opt?.textContent || sf.value || '';
  return String(raw).replace(/^店铺：/, '').split('·')[0].trim();
}
function currentSpu() {
  const t = document.getElementById('currentSpu')?.textContent?.trim() || '';
  return t === '-' ? '' : t;
}
function reportMainState() {
  if (!isMainApp()) return;
  const payload = {
    store: currentStore(),
    spu: currentSpu(),
    normal: document.getElementById('normalPrice')?.value || '',
    major: document.getElementById('majorPrice')?.value || '',
    completion: document.getElementById('storeCompletionText')?.textContent?.trim() || '',
    tab: activeTabName()
  };
  ipcRenderer.send('desktop-state-update', payload);
}
function flash(el) {
  if (!el) return;
  const old = el.style.boxShadow;
  el.style.boxShadow = '0 0 0 3px rgba(37,99,235,.32)';
  setTimeout(() => { el.style.boxShadow = old; }, 900);
}
function clickPrevSpu() {
  const items = Array.from(document.querySelectorAll('#spuList .spu-item'));
  const idx = items.findIndex(x => x.classList.contains('active'));
  if (idx > 0) items[idx - 1].click();
}
function handleCommand(cmd) {
  if (!isMainApp()) return;
  if (cmd === 'next') {
    const btn = document.getElementById('saveNext');
    if (btn) { flash(btn); btn.click(); }
  } else if (cmd === 'prev') {
    clickPrevSpu();
  } else if (cmd === 'focus') {
    const el = document.getElementById('currentSpu');
    el?.scrollIntoView({ behavior: 'smooth', block: 'center' }); flash(el);
  }
}
ipcRenderer.on('desktop-command', (_e, cmd) => handleCommand(cmd));

function injectDesktopControls() {
  if (!isMainApp() || document.getElementById('desktopBridgeBar')) return;
  const style = document.createElement('style');
  style.textContent = `
    #desktopBridgeBar{position:fixed;right:14px;bottom:14px;z-index:2500;display:flex;gap:7px;align-items:center;padding:7px 8px;background:color-mix(in srgb,var(--surface,#fff) 92%,transparent);border:1px solid var(--line,#dbe4ef);border-radius:14px;box-shadow:0 8px 26px rgba(15,23,42,.14);backdrop-filter:blur(10px)}
    #desktopBridgeBar button{width:34px;height:34px;border:1px solid var(--line,#cbd5e1);border-radius:10px;background:var(--surface,#fff);color:var(--text,#334155);font-size:17px;font-weight:700;padding:0;cursor:pointer}
    #desktopBridgeBar button:hover{border-color:#2563eb;color:#2563eb;background:#eff6ff}
    #desktopBridgeBar .desk-dot{width:8px;height:8px;border-radius:50%;background:#22c55e;box-shadow:0 0 0 3px rgba(34,197,94,.12)}
    @media(max-width:700px){#desktopBridgeBar{right:8px;bottom:8px}#desktopBridgeBar button{padding:0 8px}}
  `;
  document.head.appendChild(style);
  const bar = document.createElement('div');
  bar.id = 'desktopBridgeBar';
  bar.innerHTML = '<span class="desk-dot" title="桌面程序已连接"></span><button id="desktopFloatBtn" type="button" title="显示/隐藏悬浮图标">◉</button><button id="desktopSettingsBtn" type="button" title="设置">⚙</button>';
  document.body.appendChild(bar);
  document.getElementById('desktopFloatBtn').addEventListener('click', () => ipcRenderer.invoke('desktop:toggle-float'));
  document.getElementById('desktopSettingsBtn').addEventListener('click', () => ipcRenderer.invoke('desktop:open-settings'));
}

async function attemptRecovery() {
  if (!isMainApp()) return;
  let recovery = {};
  try { recovery = await ipcRenderer.invoke('desktop:get-recovery'); } catch { return; }
  if (!recovery?.spu && !recovery?.store) return;
  let tries = 0;
  const timer = setInterval(() => {
    tries++;
    if (recovery.store) {
      const sf = document.getElementById('storeFilter');
      if (sf && sf.options?.length && sf.value !== recovery.store) {
        const has = Array.from(sf.options).some(o => o.value === recovery.store);
        if (has) { sf.value = recovery.store; sf.dispatchEvent(new Event('change', { bubbles: true })); }
      }
    }
    if (recovery.spu) {
      const item = Array.from(document.querySelectorAll('#spuList .spu-item')).find(x => x.dataset.spu === recovery.spu);
      if (item && !item.classList.contains('active')) item.click();
    }
    if (recovery.normal && document.getElementById('normalPrice') && !document.getElementById('normalPrice').value) document.getElementById('normalPrice').value = recovery.normal;
    if (recovery.major && document.getElementById('majorPrice') && !document.getElementById('majorPrice').value) document.getElementById('majorPrice').value = recovery.major;
    if (tries > 12 || (recovery.spu && currentSpu() === recovery.spu)) clearInterval(timer);
  }, 700);
}


function hexRgb(hex) {
  const m = String(hex || '').trim().match(/^#([0-9a-f]{6})$/i);
  if (!m) return null;
  const n = parseInt(m[1], 16); return [(n>>16)&255,(n>>8)&255,n&255];
}
function mixHex(a,b,t){const A=hexRgb(a),B=hexRgb(b);if(!A||!B)return a;const c=A.map((v,i)=>Math.round(v+(B[i]-v)*t));return '#'+c.map(v=>v.toString(16).padStart(2,'0')).join('')}
async function applyDesktopTheme(s = null) {
  try {
    s = s || await ipcRenderer.invoke('desktop:get-settings');
    const assets = await ipcRenderer.invoke('desktop:get-assets');
    const root = document.documentElement;
    root.dataset.activitySnapshotEnabled = s.activitySnapshotEnabled === false ? '0' : '1';
    root.dataset.activitySnapshotKeep = String(Math.max(1, Math.min(100, Number(s.activitySnapshotKeep) || 20)));
    const primary = s.themePrimary || '#2563eb', accent=s.themeAccent||'#7c3aed', bg=s.themeBackground||'#f5f7fb', surface=s.themeSurface||'#ffffff', text=s.themeText||'#172033';
    root.style.setProperty('--blue', primary); root.style.setProperty('--purple', accent); root.style.setProperty('--bg', bg); root.style.setProperty('--surface', surface); root.style.setProperty('--card', surface); root.style.setProperty('--text', text);
    root.style.setProperty('--blue2', mixHex(primary,surface,.90)); root.style.setProperty('--purple2', mixHex(accent,surface,.91));
    root.style.setProperty('--line', mixHex(text,surface,.84)); root.style.setProperty('--muted', mixHex(text,surface,.42)); root.style.setProperty('--surface-soft', mixHex(surface,bg,.35)); root.style.setProperty('--surface-blue', mixHex(primary,surface,.95));
    root.style.setProperty('--desktop-wallpaper', s.wallpaperEnabled && assets?.wallpaperUrl ? `url("${String(assets.wallpaperUrl).replace(/"/g,'%22')}")` : 'none');
    root.style.setProperty('--desktop-wallpaper-opacity', String(Number(s.wallpaperOpacity)||0)); root.style.setProperty('--desktop-wallpaper-blur', `${Number(s.wallpaperBlur)||0}px`); root.style.setProperty('--desktop-wallpaper-fit', s.wallpaperFit || 'cover');
    const isBall = /float-ball\.html$/i.test(decodeURIComponent(location.pathname || ''));
    if (isBall) return;
    if (!document.getElementById('desktopThemeStyle')) {
      const st=document.createElement('style'); st.id='desktopThemeStyle'; st.textContent=`
        html,body{background:var(--bg)!important;color:var(--text)!important}
        body{position:relative;isolation:isolate}
        body::before{content:"";position:fixed;inset:0;z-index:-2;background-image:var(--desktop-wallpaper);background-position:center;background-repeat:no-repeat;background-size:var(--desktop-wallpaper-fit);opacity:var(--desktop-wallpaper-opacity);filter:blur(var(--desktop-wallpaper-blur));transform:scale(1.03);pointer-events:none}
        body::after{content:"";position:fixed;inset:0;z-index:-1;background:color-mix(in srgb,var(--bg) 72%,transparent);pointer-events:none}
        .card,.editor,.side,.spu-item,.history-manage,.history-manage-table,.review-wrap,.file-list,.app-shell,.workspace-pane,.settings-card,.panel-card{background:color-mix(in srgb,var(--surface) 94%,transparent)!important;color:var(--text)!important;border-color:var(--line)!important}
        input,select,textarea,button{accent-color:var(--blue)}
      `; document.head.appendChild(st);
    }
  } catch {}
}
ipcRenderer.on('desktop-settings-changed', (_e, st) => applyDesktopTheme(st));

document.addEventListener('DOMContentLoaded', () => {
  applyDesktopTheme();
  if (!isMainApp()) return;
  injectDesktopControls();
  attemptRecovery();
  setInterval(reportMainState, 900);
  reportMainState();
});
