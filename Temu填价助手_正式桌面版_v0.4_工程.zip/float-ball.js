const icon=document.getElementById('icon');
async function refresh(){const a=await window.temuDesktop.getAssets();if(a?.floatingIconUrl)icon.src=a.floatingIconUrl;}
document.getElementById('ballBtn').onclick=e=>{e.stopPropagation();window.temuDesktop.toggleHistoryPanel();};
document.addEventListener('contextmenu',e=>{e.preventDefault();window.temuDesktop.openSettings();});
window.temuDesktop.onSettingsChanged(()=>refresh());
window.temuDesktop.onState(s=>{document.body.title=s?.spu?`当前SPU：${s.spu}`:'Temu填价助手'});
refresh();
