const { app, BrowserWindow, Tray, Menu, ipcMain, globalShortcut, dialog, shell, clipboard, screen, session, nativeImage } = require('electron');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { finished } = require('stream/promises');
const { pathToFileURL } = require('url');

const APP_NAME = 'Temu填价助手';
const APP_VERSION = '0.5.1';
const ROOT = __dirname;
const ICON_ICO = path.join(ROOT, 'icons', 'app.ico');
const TRAY_PNG = path.join(ROOT, 'icons', 'tray.png');

app.setName(APP_NAME);
const appDataRoot = app.getPath('appData');
const userDataDir = path.join(appDataRoot, APP_NAME);
app.setPath('userData', userDataDir);
fs.mkdirSync(userDataDir, { recursive: true });
const ASSET_DIR = path.join(userDataDir, 'custom-assets');
fs.mkdirSync(ASSET_DIR, { recursive: true });

const SETTINGS_FILE = path.join(userDataDir, 'desktop-settings.json');
const WINDOW_FILE = path.join(userDataDir, 'window-state.json');
const FLOAT_FILE = path.join(userDataDir, 'float-window-state.json');
const RECOVERY_FILE = path.join(userDataDir, 'recovery.json');
const RESTORE_PENDING = path.join(userDataDir, 'restore-pending.json');
const BACKUP_DIR = path.join(userDataDir, 'backups');
const BACKUP_MAGIC = Buffer.from('TEMU_BACKUP_V1\n', 'utf8');
const BACKUP_ROOTS = ['Local Storage', 'IndexedDB', 'WebStorage', 'Preferences', 'desktop-settings.json', 'window-state.json', 'float-window-state.json', 'recovery.json', 'custom-assets'];

const defaults = {
  closeToTray: true,
  minimizeToTray: true,
  autoStart: false,
  autoBackup: true,
  backupIntervalMinutes: 30,
  backupKeep: 10,
  alwaysOnTop: false,
  showFloatOnStart: false,
  floatOpacity: 0.96,
  floatSize: 72,
  floatAlwaysOnTop: true,
  themeMode: 'custom',
  themePrimary: '#2563eb',
  themeAccent: '#7c3aed',
  themeBackground: '#f5f7fb',
  themeSurface: '#ffffff',
  themeText: '#172033',
  wallpaperEnabled: false,
  wallpaperOpacity: 0.18,
  wallpaperBlur: 0,
  wallpaperFit: 'cover',
  wallpaperPath: '',
  floatingIconPath: '',
  particleBackgroundEnabled: true,
  particleCount: 72,
  particleOpacity: 0.58,
  workspaceRoot: '',
  workspaceAutoScan: true,
  workspaceScanSeconds: 8,
  activitySnapshotEnabled: true,
  activitySnapshotKeep: 20,
  shortcuts: {
    toggleMain: 'CommandOrControl+Alt+T',
    toggleFloat: 'CommandOrControl+Alt+F',
    toggleHistoryPanel: 'CommandOrControl+Alt+H',
    copySpu: 'CommandOrControl+Alt+C',
    prevSpu: 'CommandOrControl+Alt+Up',
    nextSpu: 'CommandOrControl+Alt+Down'
  },
  shortcutEnabled: {
    toggleMain: true,
    toggleFloat: true,
    toggleHistoryPanel: true,
    copySpu: true,
    prevSpu: false,
    nextSpu: true
  }
};

let settings = loadJson(SETTINGS_FILE, defaults);
let mainWindow = null;
let floatWindow = null; // 圆形悬浮图标
let panelWindow = null; // 历史记录/新增SPU小面板
let settingsWindow = null;
let tray = null;
let isQuitting = false;
let quitBackupDone = false;
let autoBackupTimer = null;
let lastRendererState = { store: '', spu: '', normal: '', major: '', completion: '' };
let saveBoundsTimer = null;
let saveFloatBoundsTimer = null;
let recoveryWriteTimer = null;
let lastRecoveryPayload = '';

function loadJson(file, fallback) {
  try {
    return { ...fallback, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
  } catch {
    return JSON.parse(JSON.stringify(fallback));
  }
}
function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8');
}
function saveSettings() { writeJson(SETTINGS_FILE, settings); }
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

function applyPendingRestoreSync() {
  if (!fs.existsSync(RESTORE_PENDING)) return;
  try {
    const info = JSON.parse(fs.readFileSync(RESTORE_PENDING, 'utf8'));
    if (info?.archive && fs.existsSync(info.archive)) {
      restoreArchiveSync(info.archive);
    }
  } catch (err) {
    try { fs.writeFileSync(path.join(userDataDir, 'restore-error.log'), String(err?.stack || err), 'utf8'); } catch {}
  } finally {
    try { fs.unlinkSync(RESTORE_PENDING); } catch {}
  }
}

function safeRelative(rel) {
  if (!rel || rel.includes('..') || path.isAbsolute(rel)) throw new Error('非法备份路径');
  return rel.replace(/\\/g, '/');
}
function restoreArchiveSync(archive) {
  const gz = fs.readFileSync(archive);
  const raw = zlib.gunzipSync(gz);
  let off = 0;
  if (!raw.subarray(0, BACKUP_MAGIC.length).equals(BACKUP_MAGIC)) throw new Error('不是有效的 Temu 填价助手备份文件');
  off += BACKUP_MAGIC.length;
  const entries = [];
  while (off + 12 <= raw.length) {
    const pathLen = raw.readUInt32BE(off); off += 4;
    const dataLen = Number(raw.readBigUInt64BE(off)); off += 8;
    if (pathLen === 0) break;
    const rel = safeRelative(raw.subarray(off, off + pathLen).toString('utf8')); off += pathLen;
    const data = raw.subarray(off, off + dataLen); off += dataLen;
    entries.push({ rel, data });
  }
  for (const root of BACKUP_ROOTS) {
    const dest = path.join(userDataDir, root);
    try { fs.rmSync(dest, { recursive: true, force: true }); } catch {}
  }
  for (const e of entries) {
    const dest = path.join(userDataDir, e.rel);
    const resolved = path.resolve(dest);
    if (!resolved.startsWith(path.resolve(userDataDir) + path.sep) && resolved !== path.resolve(userDataDir)) throw new Error('恢复路径越界');
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, e.data);
  }
}

applyPendingRestoreSync();
settings = loadJson(SETTINGS_FILE, defaults);

function loadBounds(file, fallback) {
  const v = loadJson(file, fallback);
  return { x: v.x, y: v.y, width: v.width || fallback.width, height: v.height || fallback.height };
}
function boundsOnScreen(bounds) {
  const displays = screen.getAllDisplays();
  if (!Number.isFinite(bounds.x) || !Number.isFinite(bounds.y)) return false;
  return displays.some(d => {
    const a = d.workArea;
    const ix = Math.max(0, Math.min(bounds.x + bounds.width, a.x + a.width) - Math.max(bounds.x, a.x));
    const iy = Math.max(0, Math.min(bounds.y + bounds.height, a.y + a.height) - Math.max(bounds.y, a.y));
    return ix >= 120 && iy >= 80;
  });
}
function saveWindowBoundsNow() {
  if (!mainWindow || mainWindow.isDestroyed() || mainWindow.isMinimized() || mainWindow.isMaximized()) return;
  writeJson(WINDOW_FILE, mainWindow.getBounds());
}
function saveFloatBoundsNow() {
  if (!floatWindow || floatWindow.isDestroyed()) return;
  writeJson(FLOAT_FILE, floatWindow.getBounds());
}
function scheduleSaveBounds() {
  clearTimeout(saveBoundsTimer);
  saveBoundsTimer = setTimeout(saveWindowBoundsNow, 250);
}
function scheduleSaveFloatBounds() {
  clearTimeout(saveFloatBoundsTimer);
  saveFloatBoundsTimer = setTimeout(saveFloatBoundsNow, 250);
}

function createMainWindow() {
  const fallback = { width: 1500, height: 920 };
  const saved = loadBounds(WINDOW_FILE, fallback);
  const opts = {
    width: clamp(saved.width, 1050, 2600),
    height: clamp(saved.height, 700, 1600),
    minWidth: 980,
    minHeight: 650,
    show: false,
    icon: ICON_ICO,
    title: APP_NAME,
    autoHideMenuBar: true,
    backgroundColor: '#f4f6f9',
    webPreferences: {
      preload: path.join(ROOT, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  };
  if (boundsOnScreen(saved)) { opts.x = saved.x; opts.y = saved.y; }
  mainWindow = new BrowserWindow(opts);
  mainWindow.setAlwaysOnTop(!!settings.alwaysOnTop);
  mainWindow.loadFile(path.join(ROOT, 'app', 'index.html'));
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.on('move', scheduleSaveBounds);
  mainWindow.on('resize', scheduleSaveBounds);
  mainWindow.on('minimize', (e) => {
    if (settings.minimizeToTray && !isQuitting) {
      e.preventDefault();
      mainWindow.hide();
      showTrayBalloonOnce();
    }
  });
  mainWindow.on('close', (e) => {
    if (!isQuitting && settings.closeToTray) {
      e.preventDefault();
      saveWindowBoundsNow();
      mainWindow.hide();
      showTrayBalloonOnce();
    }
  });
  mainWindow.on('closed', () => { mainWindow = null; });
  mainWindow.webContents.on('render-process-gone', (_event, details) => {
    if (isQuitting || details.reason === 'clean-exit') return;
    setTimeout(() => {
      if (!mainWindow || mainWindow.isDestroyed()) createMainWindow();
      else mainWindow.reload();
    }, 700);
  });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
}

let trayBalloonShown = false;
function showTrayBalloonOnce() {
  if (trayBalloonShown || !tray) return;
  trayBalloonShown = true;
  try { tray.displayBalloon({ iconType: 'info', title: APP_NAME, content: '程序仍在托盘运行。双击托盘图标可重新打开。' }); } catch {}
}

function customAssetUrl(filePath, fallback = '') {
  try {
    if (filePath && fs.existsSync(filePath)) return pathToFileURL(filePath).href;
  } catch {}
  if (fallback) return pathToFileURL(fallback).href;
  return '';
}
function rendererAssets() {
  return {
    wallpaperUrl: customAssetUrl(settings.wallpaperPath),
    floatingIconUrl: customAssetUrl(settings.floatingIconPath, path.join(ROOT, 'icons', 'app_64.png'))
  };
}
function createFloatWindow(show = true) {
  if (floatWindow && !floatWindow.isDestroyed()) {
    if (show) floatWindow.showInactive();
    return floatWindow;
  }
  const size = clamp(Number(settings.floatSize) || 72, 52, 120);
  const fallback = { width: size, height: size };
  const saved = loadBounds(FLOAT_FILE, fallback);
  const opts = {
    width: size,
    height: size,
    show: false,
    frame: false,
    transparent: true,
    resizable: false,
    alwaysOnTop: !!settings.floatAlwaysOnTop,
    skipTaskbar: true,
    hasShadow: false,
    icon: ICON_ICO,
    title: 'Temu填价助手 · 悬浮图标',
    backgroundColor: '#00000000',
    webPreferences: {
      preload: path.join(ROOT, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  };
  if (boundsOnScreen({ x:saved.x, y:saved.y, width:size, height:size })) { opts.x = saved.x; opts.y = saved.y; }
  floatWindow = new BrowserWindow(opts);
  floatWindow.setOpacity(clamp(Number(settings.floatOpacity) || 0.96, 0.45, 1));
  floatWindow.loadFile(path.join(ROOT, 'float-ball.html'));
  floatWindow.on('move', scheduleSaveFloatBounds);
  floatWindow.on('close', (e) => {
    if (!isQuitting) { e.preventDefault(); saveFloatBoundsNow(); floatWindow.hide(); if (panelWindow && !panelWindow.isDestroyed()) panelWindow.hide(); }
  });
  floatWindow.on('closed', () => { floatWindow = null; });
  floatWindow.once('ready-to-show', () => { if (show) floatWindow.showInactive(); });
  return floatWindow;
}
function positionPanelNearBall() {
  if (!panelWindow || panelWindow.isDestroyed()) return;
  const panel = panelWindow.getBounds();
  const ball = floatWindow && !floatWindow.isDestroyed() ? floatWindow.getBounds() : { x: 80, y: 80, width: 72, height: 72 };
  const display = screen.getDisplayNearestPoint({ x: ball.x, y: ball.y });
  const a = display.workArea;
  let x = ball.x + ball.width + 10;
  let y = ball.y;
  if (x + panel.width > a.x + a.width) x = ball.x - panel.width - 10;
  x = clamp(x, a.x, a.x + a.width - panel.width);
  y = clamp(y, a.y, a.y + a.height - panel.height);
  panelWindow.setPosition(Math.round(x), Math.round(y), false);
}
function createPanelWindow(show = true) {
  if (panelWindow && !panelWindow.isDestroyed()) {
    if (show) { positionPanelNearBall(); panelWindow.show(); panelWindow.focus(); }
    return panelWindow;
  }
  panelWindow = new BrowserWindow({
    width: 560,
    height: 690,
    minWidth: 470,
    minHeight: 520,
    show: false,
    frame: false,
    resizable: true,
    alwaysOnTop: !!settings.floatAlwaysOnTop,
    skipTaskbar: true,
    icon: ICON_ICO,
    title: 'Temu填价助手 · 历史小面板',
    backgroundColor: '#00000000',
    transparent: true,
    hasShadow: false,
    webPreferences: {
      preload: path.join(ROOT, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  panelWindow.loadFile(path.join(ROOT, 'floating.html'));
  panelWindow.on('close', e => { if (!isQuitting) { e.preventDefault(); panelWindow.hide(); } });
  panelWindow.on('closed', () => { panelWindow = null; });
  panelWindow.once('ready-to-show', () => { positionPanelNearBall(); if (show) panelWindow.show(); });
  return panelWindow;
}
function toggleHistoryPanel() {
  if (!panelWindow || panelWindow.isDestroyed()) return createPanelWindow(true);
  if (panelWindow.isVisible()) panelWindow.hide(); else { positionPanelNearBall(); panelWindow.show(); panelWindow.focus(); }
}

function createSettingsWindow() {
  if (settingsWindow && !settingsWindow.isDestroyed()) { settingsWindow.show(); settingsWindow.focus(); return; }
  settingsWindow = new BrowserWindow({
    width: 720,
    height: 820,
    minWidth: 620,
    minHeight: 650,
    parent: mainWindow || undefined,
    modal: false,
    show: false,
    icon: ICON_ICO,
    title: '桌面程序设置',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(ROOT, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  settingsWindow.loadFile(path.join(ROOT, 'settings.html'));
  settingsWindow.once('ready-to-show', () => settingsWindow.show());
  settingsWindow.on('closed', () => { settingsWindow = null; });
}

function showMainWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) createMainWindow();
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
}
function toggleMainWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) return createMainWindow();
  if (mainWindow.isVisible()) mainWindow.hide(); else showMainWindow();
}
function toggleFloatWindow() {
  if (!floatWindow || floatWindow.isDestroyed()) return createFloatWindow(true);
  if (floatWindow.isVisible()) { floatWindow.hide(); if (panelWindow && !panelWindow.isDestroyed()) panelWindow.hide(); } else floatWindow.showInactive();
}
function sendMainCommand(command) {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  mainWindow.webContents.send('desktop-command', command);
}
function pushRendererState() {
  if (floatWindow && !floatWindow.isDestroyed()) floatWindow.webContents.send('desktop-state', lastRendererState);
  if (panelWindow && !panelWindow.isDestroyed()) panelWindow.webContents.send('desktop-state', lastRendererState);
}

function trayTemplate() {
  const storeLabel = lastRendererState.store ? `当前店铺：${lastRendererState.store}` : '当前店铺：—';
  const spuLabel = lastRendererState.spu ? `当前SPU：${lastRendererState.spu}` : '当前SPU：—';
  return [
    { label: '打开主窗口', click: showMainWindow },
    { label: '显示/隐藏悬浮图标', click: toggleFloatWindow },
    { label: '历史记录小面板', click: toggleHistoryPanel },
    { type: 'separator' },
    { label: storeLabel, enabled: false },
    { label: spuLabel, enabled: false },
    { label: '复制当前SPU', enabled: !!lastRendererState.spu, click: () => lastRendererState.spu && clipboard.writeText(lastRendererState.spu) },
    { label: '下一个SPU', click: () => { showMainWindow(); sendMainCommand('next'); } },
    { type: 'separator' },
    { label: '主窗口始终置顶', type: 'checkbox', checked: !!settings.alwaysOnTop, click: item => updateSettings({ alwaysOnTop: item.checked }) },
    { label: '开机自启', type: 'checkbox', checked: !!settings.autoStart, click: item => updateSettings({ autoStart: item.checked }) },
    { label: '自动备份', type: 'checkbox', checked: !!settings.autoBackup, click: item => updateSettings({ autoBackup: item.checked }) },
    { type: 'separator' },
    { label: '桌面程序设置…', click: createSettingsWindow },
    { label: '打开待处理表格文件夹', click: () => shell.openPath(ensureWorkspace().inbox) },
    { label: '打开已处理表格文件夹', click: () => shell.openPath(ensureWorkspace().processed) },
    { label: '立即备份', click: () => createAutoBackup('manual').then(p => dialog.showMessageBox({ type: 'info', message: '备份完成', detail: p || '' })).catch(showError) },
    { label: '打开备份目录', click: () => { fs.mkdirSync(BACKUP_DIR, { recursive: true }); shell.openPath(BACKUP_DIR); } },
    { label: '导出程序数据…', click: exportProgramData },
    { label: '恢复程序数据…', click: restoreProgramData },
    { label: '检查更新…', click: checkForUpdates },
    { type: 'separator' },
    { label: '退出', click: () => { isQuitting = true; app.quit(); } }
  ];
}
function rebuildTrayMenu() {
  if (!tray) return;
  tray.setContextMenu(Menu.buildFromTemplate(trayTemplate()));
  const tip = lastRendererState.store ? `${APP_NAME} · ${lastRendererState.store}` : APP_NAME;
  tray.setToolTip(tip);
}
function createTray() {
  let image = nativeImage.createFromPath(TRAY_PNG);
  if (image.isEmpty()) image = nativeImage.createFromPath(ICON_ICO);
  tray = new Tray(image);
  rebuildTrayMenu();
  tray.on('double-click', showMainWindow);
  tray.on('click', () => { if (process.platform === 'win32') showMainWindow(); });
}

function registerGlobalShortcuts() {
  globalShortcut.unregisterAll();
  const map = { ...defaults.shortcuts, ...(settings.shortcuts || {}) };
  const enabled = { ...defaults.shortcutEnabled, ...(settings.shortcutEnabled || {}) };
  const pairs = [
    ['toggleMain', map.toggleMain, toggleMainWindow],
    ['toggleFloat', map.toggleFloat, toggleFloatWindow],
    ['toggleHistoryPanel', map.toggleHistoryPanel, toggleHistoryPanel],
    ['copySpu', map.copySpu, () => { if (lastRendererState.spu) clipboard.writeText(lastRendererState.spu); }],
    ['prevSpu', map.prevSpu, () => { showMainWindow(); sendMainCommand('prev'); }],
    ['nextSpu', map.nextSpu, () => { showMainWindow(); sendMainCommand('next'); }]
  ];
  const failures = [];
  for (const [key, accelerator, fn] of pairs) {
    if (!enabled[key] || !accelerator) continue;
    try { if (!globalShortcut.register(accelerator, fn)) failures.push(accelerator); } catch { failures.push(accelerator); }
  }
  return failures;
}
function applyAutoStart() {
  if (process.platform !== 'win32') return;
  try { app.setLoginItemSettings({ openAtLogin: !!settings.autoStart, path: process.execPath }); } catch {}
}
function updateSettings(patch) {
  settings = { ...settings, ...patch, shortcuts: { ...defaults.shortcuts, ...(settings.shortcuts || {}), ...(patch.shortcuts || {}) }, shortcutEnabled: { ...defaults.shortcutEnabled, ...(settings.shortcutEnabled || {}), ...(patch.shortcutEnabled || {}) } };
  settings.floatOpacity = clamp(Number(settings.floatOpacity) || 0.96, 0.45, 1);
  settings.floatSize = clamp(Number(settings.floatSize) || 72, 52, 120);
  settings.wallpaperOpacity = clamp(Number(settings.wallpaperOpacity) || 0.18, 0, 0.8);
  settings.wallpaperBlur = clamp(Number(settings.wallpaperBlur) || 0, 0, 30);
  settings.backupIntervalMinutes = clamp(Number(settings.backupIntervalMinutes) || 30, 5, 1440);
  settings.backupKeep = clamp(Number(settings.backupKeep) || 10, 2, 100);
  settings.activitySnapshotKeep = clamp(Number(settings.activitySnapshotKeep) || 20, 1, 100);
  settings.particleCount = clamp(Number(settings.particleCount) || 72, 20, 180);
  settings.particleOpacity = clamp(Number(settings.particleOpacity) || 0.58, 0.1, 1);
  settings.workspaceScanSeconds = clamp(Number(settings.workspaceScanSeconds) || 8, 3, 120);
  saveSettings();
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.setAlwaysOnTop(!!settings.alwaysOnTop);
  if (floatWindow && !floatWindow.isDestroyed()) {
    floatWindow.setOpacity(settings.floatOpacity);
    floatWindow.setAlwaysOnTop(!!settings.floatAlwaysOnTop);
    const size = settings.floatSize; const b = floatWindow.getBounds(); floatWindow.setBounds({ x:b.x, y:b.y, width:size, height:size });
    floatWindow.webContents.send('desktop-settings-changed', settings);
  }
  if (panelWindow && !panelWindow.isDestroyed()) { panelWindow.setAlwaysOnTop(!!settings.floatAlwaysOnTop); panelWindow.webContents.send('desktop-settings-changed', settings); }
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('desktop-settings-changed', settings);
  applyAutoStart();
  setupAutoBackupTimer();
  registerGlobalShortcuts();
  rebuildTrayMenu();
  if (settingsWindow && !settingsWindow.isDestroyed()) settingsWindow.webContents.send('desktop-settings-changed', settings);
  return settings;
}

function walkFiles(rootPath, relRoot, out) {
  if (!fs.existsSync(rootPath)) return;
  const st = fs.statSync(rootPath);
  if (st.isFile()) { out.push({ abs: rootPath, rel: relRoot.replace(/\\/g, '/') }); return; }
  for (const name of fs.readdirSync(rootPath)) {
    const abs = path.join(rootPath, name);
    const rel = path.join(relRoot, name);
    const s = fs.statSync(abs);
    if (s.isDirectory()) walkFiles(abs, rel, out); else if (s.isFile()) out.push({ abs, rel: rel.replace(/\\/g, '/') });
  }
}
async function createBackupArchive(dest) {
  try { await session.defaultSession.flushStorageData(); } catch {}
  const files = [];
  for (const root of BACKUP_ROOTS) walkFiles(path.join(userDataDir, root), root, files);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const gzip = zlib.createGzip({ level: 6 });
  const out = fs.createWriteStream(dest);
  gzip.pipe(out);
  gzip.write(BACKUP_MAGIC);
  for (const f of files) {
    const p = Buffer.from(f.rel, 'utf8');
    const data = fs.readFileSync(f.abs);
    const header = Buffer.alloc(12);
    header.writeUInt32BE(p.length, 0);
    header.writeBigUInt64BE(BigInt(data.length), 4);
    gzip.write(header); gzip.write(p); gzip.write(data);
  }
  const end = Buffer.alloc(12); gzip.write(end); gzip.end();
  await finished(out);
  return dest;
}
function backupName(prefix = 'auto') {
  const d = new Date();
  const s = d.toISOString().replace(/[:.]/g, '-');
  return `${prefix}_${s}.temubak`;
}
async function pruneBackups() {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  const list = fs.readdirSync(BACKUP_DIR).filter(x => x.endsWith('.temubak')).map(name => ({ name, full: path.join(BACKUP_DIR, name), t: fs.statSync(path.join(BACKUP_DIR, name)).mtimeMs })).sort((a,b) => b.t-a.t);
  for (const x of list.slice(settings.backupKeep)) { try { fs.unlinkSync(x.full); } catch {} }
}
async function createAutoBackup(reason = 'auto') {
  if (!settings.autoBackup && reason === 'auto') return null;
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  const dest = path.join(BACKUP_DIR, backupName(reason));
  await createBackupArchive(dest);
  await pruneBackups();
  return dest;
}
function setupAutoBackupTimer() {
  if (autoBackupTimer) clearInterval(autoBackupTimer);
  autoBackupTimer = null;
  if (!settings.autoBackup) return;
  const ms = clamp(Number(settings.backupIntervalMinutes) || 30, 5, 1440) * 60 * 1000;
  autoBackupTimer = setInterval(() => createAutoBackup('auto').catch(() => {}), ms);
}
async function exportProgramData() {
  const owner = mainWindow || settingsWindow || null;
  const r = await dialog.showSaveDialog(owner, { title: '导出程序数据', defaultPath: path.join(app.getPath('documents'), `Temu填价助手_程序数据_${new Date().toISOString().slice(0,10)}.temubak`), filters: [{ name: 'Temu填价助手备份', extensions: ['temubak'] }] });
  if (r.canceled || !r.filePath) return;
  try { await createBackupArchive(r.filePath); await dialog.showMessageBox(owner, { type: 'info', message: '程序数据已导出', detail: r.filePath }); } catch (e) { showError(e); }
}
async function restoreProgramData() {
  const owner = mainWindow || settingsWindow || null;
  const r = await dialog.showOpenDialog(owner, { title: '恢复程序数据', properties: ['openFile'], filters: [{ name: 'Temu填价助手备份', extensions: ['temubak'] }] });
  if (r.canceled || !r.filePaths[0]) return;
  const confirm = await dialog.showMessageBox(owner, { type: 'warning', buttons: ['取消', '恢复并重启'], defaultId: 0, cancelId: 0, message: '恢复会覆盖当前程序数据', detail: '建议先导出一次当前程序数据作为备份。恢复后程序会自动重启。' });
  if (confirm.response !== 1) return;
  writeJson(RESTORE_PENDING, { archive: r.filePaths[0], requestedAt: Date.now() });
  isQuitting = true;
  app.relaunch();
  app.exit(0);
}

async function checkForUpdates() {
  try {
    const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'update-config.json'), 'utf8'));
    if (!cfg.manifestUrl) {
      await dialog.showMessageBox(mainWindow || settingsWindow || null, { type: 'info', message: '当前版本：' + APP_VERSION, detail: '在线更新框架已准备好，但还没有配置固定发布地址。后续正式发布后即可启用自动版本检查。' });
      return;
    }
    const res = await fetch(cfg.manifestUrl, { cache: 'no-store' });
    if (!res.ok) throw new Error(`更新服务器返回 ${res.status}`);
    const m = await res.json();
    if (!m.version) throw new Error('更新清单缺少 version');
    const newer = compareVersions(String(m.version), APP_VERSION) > 0;
    if (!newer) {
      await dialog.showMessageBox({ type: 'info', message: '已经是最新版本', detail: `当前版本 ${APP_VERSION}` });
      return;
    }
    const box = await dialog.showMessageBox({ type: 'info', buttons: ['稍后', '打开更新地址'], defaultId: 1, message: `发现新版本 ${m.version}`, detail: m.notes || '' });
    if (box.response === 1 && m.downloadUrl) shell.openExternal(m.downloadUrl);
  } catch (e) { showError(e); }
}
function compareVersions(a, b) {
  const aa = a.split('.').map(x => Number(x) || 0), bb = b.split('.').map(x => Number(x) || 0);
  for (let i=0;i<Math.max(aa.length,bb.length);i++) { const d=(aa[i]||0)-(bb[i]||0); if(d) return d; }
  return 0;
}
function showError(err) {
  dialog.showMessageBox({ type: 'error', message: '操作失败', detail: String(err?.message || err) }).catch(() => {});
}


function safeFilePart(v, fallback='未分类') {
  let s = String(v || '').trim().replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/[. ]+$/g, '');
  return (s || fallback).slice(0, 100);
}
function workspacePaths() {
  const base = settings.workspaceRoot && path.isAbsolute(settings.workspaceRoot) ? settings.workspaceRoot : path.join(app.getPath('documents'), 'Temu填价助手工作区');
  return { root:base, inbox:path.join(base,'01_待处理表格'), processed:path.join(base,'02_已处理表格'), logs:path.join(base,'03_处理记录与备份') };
}
function ensureWorkspace() { const p=workspacePaths(); for(const d of Object.values(p)) fs.mkdirSync(d,{recursive:true}); return p; }
function isArchivedOriginalName(name){return /_原表(?:_\d+)?\.xlsx$/i.test(String(name||''))}
function workspaceInfo() { const p=ensureWorkspace(); let count=0; try{count=fs.readdirSync(p.inbox).filter(n=>/\.xlsx$/i.test(n)&&!n.startsWith('~$')&&!isArchivedOriginalName(n)).length}catch{} return {...p,pendingCount:count,autoScan:settings.workspaceAutoScan!==false,scanSeconds:clamp(Number(settings.workspaceScanSeconds)||8,3,120)}; }
async function chooseWorkspaceRoot() { const owner=settingsWindow||mainWindow||null; const r=await dialog.showOpenDialog(owner,{title:'选择 Temu 填价助手工作区',properties:['openDirectory','createDirectory']}); if(r.canceled||!r.filePaths[0])return workspaceInfo(); updateSettings({workspaceRoot:r.filePaths[0]}); return workspaceInfo(); }
function assertInboxPath(filePath){const p=ensureWorkspace(),a=path.resolve(p.inbox)+path.sep,b=path.resolve(String(filePath||''));if(!b.startsWith(a))throw new Error('文件不在待处理表格文件夹中');return b;}
function listWorkspaceInputFiles(){const p=ensureWorkspace(),arr=[];for(const name of fs.readdirSync(p.inbox)){if(!/\.xlsx$/i.test(name)||name.startsWith('~$')||isArchivedOriginalName(name))continue;const full=path.join(p.inbox,name);try{const st=fs.statSync(full);if(!st.isFile())continue;arr.push({id:`${full}|${st.size}|${Math.round(st.mtimeMs)}`,name,path:full,size:st.size,mtime:st.mtimeMs})}catch{}}return arr.sort((a,b)=>b.mtime-a.mtime)}
function readWorkspaceInputFile(filePath){const full=assertInboxPath(filePath),st=fs.statSync(full);return{name:path.basename(full),path:full,size:st.size,mtime:st.mtimeMs,base64:fs.readFileSync(full).toString('base64')}}
function uniqueOutputPath(dir,name){const ext=path.extname(name),stem=path.basename(name,ext);let out=path.join(dir,name),i=2;while(fs.existsSync(out))out=path.join(dir,`${stem}_${i++}${ext}`);return out}
function appendWorkspaceLedger(entry){const p=ensureWorkspace();fs.appendFileSync(path.join(p.logs,'处理记录.jsonl'),JSON.stringify(entry)+'\n','utf8')}
function saveProcessedWorkspaceFile(payload={}){
  const p=ensureWorkspace(),store=safeFilePart(payload.store,'未分类店铺'),d=new Date(),day=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`,dir=path.join(p.processed,store,day);
  fs.mkdirSync(dir,{recursive:true});
  let name=safeFilePart(payload.name,'已处理.xlsx'); if(!/\.xlsx$/i.test(name))name+='.xlsx';
  const dest=uniqueOutputPath(dir,name);
  let data=payload.data;
  if(data instanceof ArrayBuffer)data=Buffer.from(new Uint8Array(data));
  else if(ArrayBuffer.isView(data))data=Buffer.from(data.buffer,data.byteOffset,data.byteLength);
  else if(data?.type==='Buffer'&&Array.isArray(data.data))data=Buffer.from(data.data);
  else if(typeof data==='string')data=Buffer.from(data,'base64');
  else if(!Buffer.isBuffer(data))throw new Error('导出数据格式无效');
  fs.writeFileSync(dest,data);

  let sourceOriginal='',sourceRenamedTo='',renameWarning='';
  if(payload.sourcePath){
    try{
      sourceOriginal=assertInboxPath(payload.sourcePath);
      if(fs.existsSync(sourceOriginal)){
        const outputStem=path.basename(dest,path.extname(dest));
        const desired=path.join(path.dirname(sourceOriginal),`${outputStem}_原表.xlsx`);
        sourceRenamedTo=uniqueOutputPath(path.dirname(desired),path.basename(desired));
        fs.renameSync(sourceOriginal,sourceRenamedTo);
      }
    }catch(err){renameWarning=String(err?.message||err)}
  }
  appendWorkspaceLedger({at:new Date().toISOString(),store,source:String(payload.sourceName||''),sourceOriginal,sourceRenamedTo,renameWarning,output:dest,stats:payload.stats&&typeof payload.stats==='object'?payload.stats:{}});
  return{ok:true,path:dest,folder:dir,store,day,sourceOriginal,sourceRenamedTo,renameWarning}
}

async function chooseCustomAsset(kind) {
  const isWallpaper = kind === 'wallpaper';
  const owner = settingsWindow || mainWindow || null;
  const r = await dialog.showOpenDialog(owner, {
    title: isWallpaper ? '选择页面背景壁纸' : '选择悬浮图标',
    properties: ['openFile'],
    filters: [{ name: '图片', extensions: ['png','jpg','jpeg','webp','bmp','gif','ico'] }]
  });
  if (r.canceled || !r.filePaths[0]) return null;
  const src = r.filePaths[0];
  const ext = path.extname(src).toLowerCase() || '.png';
  const dest = path.join(ASSET_DIR, (isWallpaper ? 'wallpaper' : 'floating-icon') + ext);
  for (const name of fs.readdirSync(ASSET_DIR)) {
    if (name.startsWith(isWallpaper ? 'wallpaper.' : 'floating-icon.')) { try { fs.unlinkSync(path.join(ASSET_DIR, name)); } catch {} }
  }
  fs.copyFileSync(src, dest);
  updateSettings(isWallpaper ? { wallpaperPath: dest, wallpaperEnabled: true } : { floatingIconPath: dest });
  return { path: dest, url: customAssetUrl(dest) };
}
function resetCustomAsset(kind) {
  const isWallpaper = kind === 'wallpaper';
  const p = isWallpaper ? settings.wallpaperPath : settings.floatingIconPath;
  if (p && String(p).startsWith(ASSET_DIR)) { try { fs.unlinkSync(p); } catch {} }
  updateSettings(isWallpaper ? { wallpaperPath: '', wallpaperEnabled: false } : { floatingIconPath: '' });
  return rendererAssets();
}
async function callMainBridge(method, payload = null) {
  if (!mainWindow || mainWindow.isDestroyed()) createMainWindow();
  try { await mainWindow.webContents.executeJavaScript('document.readyState'); } catch {}
  const code = `window.TemuDesktopBridge && window.TemuDesktopBridge[${JSON.stringify(method)}] ? window.TemuDesktopBridge[${JSON.stringify(method)}](${JSON.stringify(payload)}) : null`;
  try { return await mainWindow.webContents.executeJavaScript(code, true); }
  catch (err) { throw new Error('主程序历史数据尚未准备好：' + (err?.message || err)); }
}

ipcMain.handle('desktop:get-workspace-info', () => workspaceInfo());
ipcMain.handle('desktop:choose-workspace-root', () => chooseWorkspaceRoot());
ipcMain.handle('desktop:open-workspace-root', () => shell.openPath(ensureWorkspace().root));
ipcMain.handle('desktop:open-workspace-inbox', () => shell.openPath(ensureWorkspace().inbox));
ipcMain.handle('desktop:open-workspace-processed', () => shell.openPath(ensureWorkspace().processed));
ipcMain.handle('desktop:workspace-list-files', () => listWorkspaceInputFiles());
ipcMain.handle('desktop:workspace-read-file', (_e, filePath) => readWorkspaceInputFile(filePath));
ipcMain.handle('desktop:workspace-save-processed', (_e, payload) => saveProcessedWorkspaceFile(payload || {}));
ipcMain.handle('desktop:show-main-from-panel', () => { showMainWindow(); if (panelWindow && !panelWindow.isDestroyed()) panelWindow.hide(); return true; });
ipcMain.handle('desktop:close-floating-ui', () => { if (panelWindow && !panelWindow.isDestroyed()) panelWindow.hide(); if (floatWindow && !floatWindow.isDestroyed()) floatWindow.hide(); return true; });
ipcMain.on('desktop:move-float', (_e, pos) => { if (!floatWindow || floatWindow.isDestroyed() || !pos) return; const b=floatWindow.getBounds(),display=screen.getDisplayNearestPoint({x:Number(pos.x)||b.x,y:Number(pos.y)||b.y}),a=display.workArea; const x=clamp(Math.round(Number(pos.x)||b.x),a.x,a.x+a.width-b.width),y=clamp(Math.round(Number(pos.y)||b.y),a.y,a.y+a.height-b.height); floatWindow.setPosition(x,y,false); scheduleSaveFloatBounds(); });
ipcMain.handle('desktop:get-float-bounds', () => floatWindow && !floatWindow.isDestroyed() ? floatWindow.getBounds() : null);
ipcMain.handle('desktop:get-settings', () => settings);
ipcMain.handle('desktop:get-assets', () => rendererAssets());
ipcMain.handle('desktop:choose-wallpaper', () => chooseCustomAsset('wallpaper'));
ipcMain.handle('desktop:reset-wallpaper', () => resetCustomAsset('wallpaper'));
ipcMain.handle('desktop:choose-floating-icon', () => chooseCustomAsset('floatingIcon'));
ipcMain.handle('desktop:reset-floating-icon', () => resetCustomAsset('floatingIcon'));
ipcMain.handle('desktop:toggle-history-panel', () => { toggleHistoryPanel(); return true; });
ipcMain.handle('desktop:history-search', (_e, q) => callMainBridge('searchHistory', q));
ipcMain.handle('desktop:history-detail', (_e, spu) => callMainBridge('historyDetail', spu));
ipcMain.handle('desktop:history-add', (_e, payload) => callMainBridge('addHistory', payload));
ipcMain.handle('desktop:history-update', (_e, payload) => callMainBridge('updateHistory', payload));
ipcMain.handle('desktop:history-set-image', (_e, payload) => callMainBridge('setHistoryImage', payload));
ipcMain.handle('desktop:update-settings', (_e, patch) => updateSettings(patch || {}));
ipcMain.handle('desktop:get-state', () => lastRendererState);
ipcMain.handle('desktop:get-recovery', () => loadJson(RECOVERY_FILE, {}));
ipcMain.handle('desktop:open-settings', () => { createSettingsWindow(); return true; });
ipcMain.handle('desktop:toggle-float', () => { toggleFloatWindow(); return true; });
ipcMain.handle('desktop:show-main', () => { showMainWindow(); return true; });
ipcMain.handle('desktop:hide-float', () => { if (floatWindow && !floatWindow.isDestroyed()) floatWindow.hide(); return true; });
ipcMain.handle('desktop:command', (_e, cmd) => { if (cmd === 'copy') { if (lastRendererState.spu) clipboard.writeText(lastRendererState.spu); } else if (String(cmd||'').startsWith('copyText:')) { clipboard.writeText(String(cmd).slice(9)); } else { showMainWindow(); sendMainCommand(cmd); } return true; });
ipcMain.handle('desktop:set-float-opacity', (_e, value) => updateSettings({ floatOpacity: value }));
ipcMain.handle('desktop:export-data', exportProgramData);
ipcMain.handle('desktop:restore-data', restoreProgramData);
ipcMain.handle('desktop:backup-now', () => createAutoBackup('manual'));
ipcMain.handle('desktop:open-backup-dir', () => { fs.mkdirSync(BACKUP_DIR, { recursive: true }); return shell.openPath(BACKUP_DIR); });
ipcMain.handle('desktop:check-updates', checkForUpdates);
ipcMain.on('desktop-state-update', (_e, state) => {
  if (!state || typeof state !== 'object') return;
  const next = {
    store: String(state.store || ''),
    spu: String(state.spu || ''),
    normal: String(state.normal || ''),
    major: String(state.major || ''),
    completion: String(state.completion || ''),
    tab: String(state.tab || '')
  };
  const changed = JSON.stringify(next) !== JSON.stringify(lastRendererState);
  lastRendererState = next;
  if (changed) { pushRendererState(); rebuildTrayMenu(); }
  const payload = JSON.stringify({ ...next, updatedAt: Date.now() });
  if (payload !== lastRecoveryPayload) {
    lastRecoveryPayload = payload;
    clearTimeout(recoveryWriteTimer);
    recoveryWriteTimer = setTimeout(() => { try { writeJson(RECOVERY_FILE, JSON.parse(payload)); } catch {} }, 500);
  }
});

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => showMainWindow());
  app.whenReady().then(() => {
    Menu.setApplicationMenu(null);
    createTray();
    createMainWindow();
    if (settings.showFloatOnStart) createFloatWindow(true);
    applyAutoStart();
    registerGlobalShortcuts();
    setupAutoBackupTimer();
  });
}

app.on('activate', () => showMainWindow());
app.on('window-all-closed', () => { /* 托盘程序保持运行 */ });
app.on('before-quit', (e) => {
  if (isQuitting && (!settings.autoBackup || quitBackupDone)) return;
  isQuitting = true;
  saveWindowBoundsNow(); saveFloatBoundsNow();
  if (settings.autoBackup && !quitBackupDone) {
    e.preventDefault();
    quitBackupDone = true;
    createAutoBackup('quit').catch(() => {}).finally(() => app.exit(0));
  }
});
app.on('will-quit', () => { globalShortcut.unregisterAll(); });
