const icon=document.getElementById('icon'),ball=document.getElementById('ball');let down=null,start=null,moved=false;
async function refresh(){const a=await window.temuDesktop.getAssets();if(a?.floatingIconUrl)icon.src=a.floatingIconUrl;}
ball.addEventListener('pointerdown',async e=>{if(e.button!==0)return;down={x:e.screenX,y:e.screenY};start=await window.temuDesktop.getFloatBounds();moved=false;ball.classList.add('dragging');ball.setPointerCapture(e.pointerId)});
ball.addEventListener('pointermove',e=>{if(!down||!start)return;const dx=e.screenX-down.x,dy=e.screenY-down.y;if(Math.hypot(dx,dy)>4)moved=true;if(moved)window.temuDesktop.moveFloat({x:start.x+dx,y:start.y+dy})});
ball.addEventListener('pointerup',e=>{ball.classList.remove('dragging');try{ball.releasePointerCapture(e.pointerId)}catch{};const click=!moved;down=null;start=null;if(click)window.temuDesktop.toggleHistoryPanel()});
document.addEventListener('contextmenu',e=>{e.preventDefault();window.temuDesktop.openSettings();});window.temuDesktop.onSettingsChanged(()=>refresh());window.temuDesktop.onState(s=>{document.body.title=s?.spu?`当前SPU：${s.spu}`:'Temu填价助手'});refresh();
