$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host '=== Temu填价助手 Windows 便携版构建 ===' -ForegroundColor Cyan
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host '未检测到 Node.js。请先安装 Node.js LTS，然后重新运行此脚本。' -ForegroundColor Yellow
  Start-Process 'https://nodejs.org/'
  Read-Host '按 Enter 退出'
  exit 1
}
Write-Host ('Node: ' + (node -v))
Write-Host '安装构建依赖...'
npm install
Write-Host '开始生成 Windows x64 便携 EXE...'
npm run dist:win
Write-Host '构建完成。请查看 dist 文件夹。' -ForegroundColor Green
Start-Process (Join-Path $PSScriptRoot 'dist')
Read-Host '按 Enter 退出'
