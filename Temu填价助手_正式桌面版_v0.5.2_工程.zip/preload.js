const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('temuDesktop', {
  getSettings: () => ipcRenderer.invoke('desktop:get-settings'),
  getWorkspaceInfo: () => ipcRenderer.invoke('desktop:get-workspace-info'),
  chooseWorkspaceRoot: () => ipcRenderer.invoke('desktop:choose-workspace-root'),
  openWorkspaceRoot: () => ipcRenderer.invoke('desktop:open-workspace-root'),
  openWorkspaceInbox: () => ipcRenderer.invoke('desktop:open-workspace-inbox'),
  openWorkspaceProcessed: () => ipcRenderer.invoke('desktop:open-workspace-processed'),
  openWorkspaceLogs: () => ipcRenderer.invoke('desktop:open-workspace-logs'),
  workspaceListFiles: () => ipcRenderer.invoke('desktop:workspace-list-files'),
  workspaceReadFile: p => ipcRenderer.invoke('desktop:workspace-read-file', p),
  workspaceSaveProcessed: payload => ipcRenderer.invoke('desktop:workspace-save-processed', payload),
  showMainFromPanel: () => ipcRenderer.invoke('desktop:show-main-from-panel'),
  closeFloatingUi: () => ipcRenderer.invoke('desktop:close-floating-ui'),
  getFloatBounds: () => ipcRenderer.invoke('desktop:get-float-bounds'),
  moveFloat: pos => ipcRenderer.send('desktop:move-float', pos),
  getAssets: () => ipcRenderer.invoke('desktop:get-assets'),
  updateSettings: patch => ipcRenderer.invoke('desktop:update-settings', patch),
  chooseWallpaper: () => ipcRenderer.invoke('desktop:choose-wallpaper'),
  resetWallpaper: () => ipcRenderer.invoke('desktop:reset-wallpaper'),
  chooseFloatingIcon: () => ipcRenderer.invoke('desktop:choose-floating-icon'),
  resetFloatingIcon: () => ipcRenderer.invoke('desktop:reset-floating-icon'),
  toggleHistoryPanel: () => ipcRenderer.invoke('desktop:toggle-history-panel'),
  historySearch: q => ipcRenderer.invoke('desktop:history-search', q),
  historyDetail: spu => ipcRenderer.invoke('desktop:history-detail', spu),
  historyAdd: payload => ipcRenderer.invoke('desktop:history-add', payload),
  historyUpdate: payload => ipcRenderer.invoke('desktop:history-update', payload),
  historySetImage: payload => ipcRenderer.invoke('desktop:history-set-image', payload),
  getState: () => ipcRenderer.invoke('desktop:get-state'),
  getRecovery: () => ipcRenderer.invoke('desktop:get-recovery'),
  openSettings: () => ipcRenderer.invoke('desktop:open-settings'),
  toggleFloat: () => ipcRenderer.invoke('desktop:toggle-float'),
  showMain: () => ipcRenderer.invoke('desktop:show-main'),
  hideFloat: () => ipcRenderer.invoke('desktop:hide-float'),
  command: cmd => ipcRenderer.invoke('desktop:command', cmd),
  setFloatOpacity: value => ipcRenderer.invoke('desktop:set-float-opacity', value),
  exportData: () => ipcRenderer.invoke('desktop:export-data'),
  restoreData: () => ipcRenderer.invoke('desktop:restore-data'),
  backupNow: () => ipcRenderer.invoke('desktop:backup-now'),
  openBackupDir: () => ipcRenderer.invoke('desktop:open-backup-dir'),
  checkUpdates: () => ipcRenderer.invoke('desktop:check-updates'),
  onState: fn => ipcRenderer.on('desktop-state', (_e, state) => fn(state)),
  onSettingsChanged: fn => ipcRenderer.on('desktop-settings-changed', (_e, settings) => fn(settings))
});

function isMainApp() {
  return /[\\/]app[\\/]index\.html$/i.test(decodeURIComponent(location.pathname || '')) || /\/app\/index\.html$/i.test(location.pathname || '');
}
function activeTabName() {
  const active = document.querySelector('.app-tab.active');
  return active?.textContent?.trim() || '';
}
function currentStore() {
  const sf = document.getElementById('storeFilter');
  if (!sf) return '';
  const opt = sf.options?.[sf.selectedIndex];
  const raw = opt?.textContent || sf.value || '';
  return String(raw).replace(/^店铺：/, '').split('·')[0].trim();
}
function currentSpu() {
  const t = document.getElementById('currentSpu')?.textContent?.trim() || '';
  return t === '-' ? '' : t;
}
function reportMainState() {
  if (!isMainApp()) return;
  const payload = {
    store: currentStore(),
    spu: currentSpu(),
    normal: document.getElementById('normalPrice')?.value || '',
    major: document.getElementById('majorPrice')?.value || '',
    completion: document.getElementById('storeCompletionText')?.textContent?.trim() || '',
    tab: activeTabName()
  };
  ipcRenderer.send('desktop-state-update', payload);
}
function flash(el) {
  if (!el) return;
  const old = el.style.boxShadow;
  el.style.boxShadow = '0 0 0 3px rgba(37,99,235,.32)';
  setTimeout(() => { el.style.boxShadow = old; }, 900);
}
function clickPrevSpu() {
  const items = Array.from(document.querySelectorAll('#spuList .spu-item'));
  const idx = items.findIndex(x => x.classList.contains('active'));
  if (idx > 0) items[idx - 1].click();
}
function handleCommand(cmd) {
  if (!isMainApp()) return;
  if (cmd === 'next') {
    const btn = document.getElementById('saveNext');
    if (btn) { flash(btn); btn.click(); }
  } else if (cmd === 'prev') {
    clickPrevSpu();
  } else if (cmd === 'focus') {
    const el = document.getElementById('currentSpu');
    el?.scrollIntoView({ behavior: 'smooth', block: 'center' }); flash(el);
  }
}
ipcRenderer.on('desktop-command', (_e, cmd) => handleCommand(cmd));

function injectDesktopControls() {
  if (!isMainApp() || document.getElementById('desktopBridgeBar')) return;
  const style = document.createElement('style');
  style.textContent = `
    #desktopBridgeBar{position:fixed;right:14px;bottom:14px;z-index:2500;display:flex;gap:7px;align-items:center;padding:7px 8px;background:color-mix(in srgb,var(--surface,#fff) 92%,transparent);border:1px solid var(--line,#dbe4ef);border-radius:14px;box-shadow:0 8px 26px rgba(15,23,42,.14);backdrop-filter:blur(10px)}
    #desktopBridgeBar button{width:34px;height:34px;border:1px solid var(--line,#cbd5e1);border-radius:10px;background:var(--surface,#fff);color:var(--text,#334155);font-size:17px;font-weight:700;padding:0;cursor:pointer}
    #desktopBridgeBar button:hover{border-color:#2563eb;color:#2563eb;background:#eff6ff}
    #desktopBridgeBar .desk-dot{width:8px;height:8px;border-radius:50%;background:#22c55e;box-shadow:0 0 0 3px rgba(34,197,94,.12)}
    @media(max-width:700px){#desktopBridgeBar{right:8px;bottom:8px}#desktopBridgeBar button{padding:0 8px}}
  `;
  document.head.appendChild(style);
  const bar = document.createElement('div');
  bar.id = 'desktopBridgeBar';
  bar.innerHTML = '<span class="desk-dot" title="桌面程序已连接"></span><button id="desktopFloatBtn" type="button" title="显示/隐藏悬浮图标">◉</button><button id="desktopSettingsBtn" type="button" title="设置">⚙</button>';
  document.body.appendChild(bar);
  document.getElementById('desktopFloatBtn').addEventListener('click', () => ipcRenderer.invoke('desktop:toggle-float'));
  document.getElementById('desktopSettingsBtn').addEventListener('click', () => ipcRenderer.invoke('desktop:open-settings'));
}

async function attemptRecovery() {
  if (!isMainApp()) return;
  let recovery = {};
  try { recovery = await ipcRenderer.invoke('desktop:get-recovery'); } catch { return; }
  if (!recovery?.spu && !recovery?.store) return;
  let tries = 0;
  const timer = setInterval(() => {
    tries++;
    if (recovery.store) {
      const sf = document.getElementById('storeFilter');
      if (sf && sf.options?.length && sf.value !== recovery.store) {
        const has = Array.from(sf.options).some(o => o.value === recovery.store);
        if (has) { sf.value = recovery.store; sf.dispatchEvent(new Event('change', { bubbles: true })); }
      }
    }
    if (recovery.spu) {
      const item = Array.from(document.querySelectorAll('#spuList .spu-item')).find(x => x.dataset.spu === recovery.spu);
      if (item && !item.classList.contains('active')) item.click();
    }
    if (recovery.normal && document.getElementById('normalPrice') && !document.getElementById('normalPrice').value) document.getElementById('normalPrice').value = recovery.normal;
    if (recovery.major && document.getElementById('majorPrice') && !document.getElementById('majorPrice').value) document.getElementById('majorPrice').value = recovery.major;
    if (tries > 12 || (recovery.spu && currentSpu() === recovery.spu)) clearInterval(timer);
  }, 700);
}


function hexRgb(hex) {
  const m = String(hex || '').trim().match(/^#([0-9a-f]{6})$/i);
  if (!m) return null;
  const n = parseInt(m[1], 16); return [(n>>16)&255,(n>>8)&255,n&255];
}
function mixHex(a,b,t){const A=hexRgb(a),B=hexRgb(b);if(!A||!B)return a;const c=A.map((v,i)=>Math.round(v+(B[i]-v)*t));return '#'+c.map(v=>v.toString(16).padStart(2,'0')).join('')}

let desktopParticleState={canvas:null,ctx:null,items:[],raf:0,settings:null};
function syncParticleLayer(st,primary,accent){
  const pagePath=decodeURIComponent(location.pathname||''); const isBall=/float-ball\.html$/i.test(pagePath),isPanel=/(^|\/)floating\.html$/i.test(pagePath); if(isBall||isPanel)return;
  if(st?.particleBackgroundEnabled===false){if(desktopParticleState.canvas)desktopParticleState.canvas.style.display='none';return}
  let c=desktopParticleState.canvas;
  if(!c){c=document.createElement('canvas');c.id='desktopParticleCanvas';c.style.cssText='position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:0;';document.body.insertBefore(c,document.body.firstChild);desktopParticleState.canvas=c;desktopParticleState.ctx=c.getContext('2d');}
  c.style.display='block';desktopParticleState.settings={count:Math.max(20,Math.min(180,Number(st?.particleCount)||72)),opacity:Math.max(.1,Math.min(1,Number(st?.particleOpacity)||.58)),primary,accent};
  const reset=()=>{const d=Math.min(2,devicePixelRatio||1),w=innerWidth,h=innerHeight;c.width=Math.round(w*d);c.height=Math.round(h*d);c.style.width=w+'px';c.style.height=h+'px';desktopParticleState.ctx.setTransform(d,0,0,d,0,0);desktopParticleState.items=Array.from({length:desktopParticleState.settings.count},()=>({x:Math.random()*w,y:Math.random()*h,vx:(Math.random()-.5)*.24,vy:(Math.random()-.5)*.24,r:Math.random()*1.35+.45,a:Math.random()*.55+.15}))};
  reset(); if(!c.dataset.bound){c.dataset.bound='1';addEventListener('resize',reset)}
  if(desktopParticleState.raf)return;
  const rgb=hex=>{const v=hexRgb(hex);return v||[165,180,252]};
  const draw=()=>{const ctx=desktopParticleState.ctx,cf=desktopParticleState.settings;if(!ctx||!cf){desktopParticleState.raf=requestAnimationFrame(draw);return}const w=innerWidth,h=innerHeight,ca=rgb(cf.primary),cb=rgb(cf.accent);ctx.clearRect(0,0,w,h);for(let i=0;i<desktopParticleState.items.length;i++){const p=desktopParticleState.items[i];p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>w)p.vx*=-1;if(p.y<0||p.y>h)p.vy*=-1;const cc=i%2?ca:cb;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fillStyle=`rgba(${cc[0]},${cc[1]},${cc[2]},${p.a*cf.opacity})`;ctx.fill()}for(let i=0;i<desktopParticleState.items.length;i++)for(let j=i+1;j<desktopParticleState.items.length;j++){const a=desktopParticleState.items[i],b=desktopParticleState.items[j],d=Math.hypot(a.x-b.x,a.y-b.y);if(d<92){ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle=`rgba(${ca[0]},${ca[1]},${ca[2]},${(1-d/92)*.055*cf.opacity})`;ctx.stroke()}}desktopParticleState.raf=requestAnimationFrame(draw)};desktopParticleState.raf=requestAnimationFrame(draw);
}

async function applyDesktopTheme(s = null) {
  try {
    s = s || await ipcRenderer.invoke('desktop:get-settings');
    const assets = await ipcRenderer.invoke('desktop:get-assets');
    const root = document.documentElement;
    root.dataset.activitySnapshotEnabled = s.activitySnapshotEnabled === false ? '0' : '1';
    root.dataset.activitySnapshotKeep = String(Math.max(1, Math.min(100, Number(s.activitySnapshotKeep) || 20)));
    const primary = s.themePrimary || '#2563eb', accent=s.themeAccent||'#7c3aed', bg=s.themeBackground||'#f5f7fb', surface=s.themeSurface||'#ffffff', text=s.themeText||'#172033';
    root.style.setProperty('--blue', primary); root.style.setProperty('--purple', accent); root.style.setProperty('--bg', bg); root.style.setProperty('--surface', surface); root.style.setProperty('--card', surface); root.style.setProperty('--text', text);
    root.style.setProperty('--blue2', mixHex(primary,surface,.90)); root.style.setProperty('--purple2', mixHex(accent,surface,.91));
    root.style.setProperty('--line', mixHex(text,surface,.84)); root.style.setProperty('--muted', mixHex(text,surface,.42)); root.style.setProperty('--surface-soft', mixHex(surface,bg,.35)); root.style.setProperty('--surface-blue', mixHex(primary,surface,.95));
    root.style.setProperty('--desktop-wallpaper', s.wallpaperEnabled && assets?.wallpaperUrl ? `url("${String(assets.wallpaperUrl).replace(/"/g,'%22')}")` : 'none');
    root.style.setProperty('--desktop-wallpaper-opacity', String(Number(s.wallpaperOpacity)||0)); root.style.setProperty('--desktop-wallpaper-blur', `${Number(s.wallpaperBlur)||0}px`); root.style.setProperty('--desktop-wallpaper-fit', s.wallpaperFit || 'cover');
    root.style.setProperty('--desktop-particle-opacity', String(Number(s.particleOpacity)||.58)); syncParticleLayer(s,primary,accent);
    const pagePath = decodeURIComponent(location.pathname || ''), isBall = /float-ball\.html$/i.test(pagePath), isPanel = /(^|\/)floating\.html$/i.test(pagePath);
    if (isBall || isPanel) return;
    if (!document.getElementById('desktopThemeStyle')) {
      const st=document.createElement('style'); st.id='desktopThemeStyle'; st.textContent=`
        html,body{background:var(--bg)!important;color:var(--text)!important}
        body{position:relative;isolation:isolate}
        body::before{content:"";position:fixed;inset:0;z-index:-2;background-image:var(--desktop-wallpaper);background-position:center;background-repeat:no-repeat;background-size:var(--desktop-wallpaper-fit);opacity:var(--desktop-wallpaper-opacity);filter:blur(var(--desktop-wallpaper-blur));transform:scale(1.03);pointer-events:none}
        body::after{content:"";position:fixed;inset:0;z-index:-1;background:color-mix(in srgb,var(--bg) 72%,transparent);pointer-events:none}
        .card,.editor,.side,.spu-item,.history-manage,.history-manage-table,.review-wrap,.file-list,.app-shell,.workspace-pane,.settings-card,.panel-card{background:color-mix(in srgb,var(--surface) 94%,transparent)!important;color:var(--text)!important;border-color:var(--line)!important}
        input,select,textarea,button{accent-color:var(--blue)}
      `; document.head.appendChild(st);
    }
  } catch {}
}
ipcRenderer.on('desktop-settings-changed', (_e, st) => applyDesktopTheme(st));

document.addEventListener('DOMContentLoaded', () => {
  applyDesktopTheme();
  if (!isMainApp()) return;
  injectDesktopControls();
  attemptRecovery();
  setInterval(reportMainState, 900);
  reportMainState();
});
