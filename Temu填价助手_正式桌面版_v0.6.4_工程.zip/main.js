const { app, BrowserWindow, Tray, Menu, ipcMain, globalShortcut, dialog, shell, clipboard, screen, session, nativeImage, Notification } = require('electron');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { finished } = require('stream/promises');
const { pathToFileURL } = require('url');

const APP_NAME = 'Temu填价助手';
const APP_VERSION = '0.6.4';
const ROOT = __dirname;
const ICON_ICO = path.join(ROOT, 'icons', 'app.ico');
const TRAY_PNG = path.join(ROOT, 'icons', 'tray.png');

app.setName(APP_NAME);
if (process.platform === 'win32') app.setAppUserModelId('com.gehu.temupricingassistant');
const appDataRoot = app.getPath('appData');
const userDataDir = path.join(appDataRoot, APP_NAME);
app.setPath('userData', userDataDir);
fs.mkdirSync(userDataDir, { recursive: true });
const ASSET_DIR = path.join(userDataDir, 'custom-assets');
fs.mkdirSync(ASSET_DIR, { recursive: true });

const SETTINGS_FILE = path.join(userDataDir, 'desktop-settings.json');
const WINDOW_FILE = path.join(userDataDir, 'window-state.json');
const FLOAT_FILE = path.join(userDataDir, 'floating-dock-state.json');
const RECOVERY_FILE = path.join(userDataDir, 'recovery.json');
const RESTORE_PENDING = path.join(userDataDir, 'restore-pending.json');
const BACKUP_DIR = path.join(userDataDir, 'backups');
const BACKUP_MAGIC = Buffer.from('TEMU_BACKUP_V1\n', 'utf8');
const BACKUP_ROOTS = ['Local Storage', 'IndexedDB', 'WebStorage', 'Preferences', 'desktop-settings.json', 'window-state.json', 'floating-dock-state.json', 'recovery.json', 'custom-assets'];

const defaults = {
  closeToTray: true,
  minimizeToTray: true,
  autoStart: false,
  autoBackup: true,
  backupIntervalMinutes: 30,
  backupKeep: 10,
  alwaysOnTop: false,
  showFloatOnStart: true,
  floatAlwaysOnTop: true,
  floatPanelWidth: 560,
  themeMode: 'custom',
  themePrimary: '#2563eb',
  themeAccent: '#7c3aed',
  themeBackground: '#f5f7fb',
  themeSurface: '#ffffff',
  themeText: '#172033',
  wallpaperEnabled: false,
  wallpaperOpacity: 0.18,
  wallpaperBlur: 0,
  wallpaperFit: 'cover',
  wallpaperPath: '',
  particleBackgroundEnabled: true,
  particleCount: 72,
  particleOpacity: 0.58,
  workspaceRoot: '',
  workspaceAutoScan: true,
  workspaceScanSeconds: 8,
  activitySnapshotEnabled: true,
  activitySnapshotKeep: 20,
  activityReminderEnabled: false,
  activityReminderDays: [1, 4],
  activityReminderTime: '09:30',
  activityReminderText: '记得报名活动',
  activityReminderLastFiredKey: '',
  shortcuts: {
    toggleMain: 'CommandOrControl+Alt+T',
    toggleFloat: 'CommandOrControl+Alt+F',
    toggleHistoryPanel: 'CommandOrControl+Alt+H',
    copySpu: 'CommandOrControl+Alt+C',
    prevSpu: 'CommandOrControl+Alt+Up',
    nextSpu: 'CommandOrControl+Alt+Down'
  },
  shortcutEnabled: {
    toggleMain: true,
    toggleFloat: true,
    toggleHistoryPanel: true,
    copySpu: true,
    prevSpu: false,
    nextSpu: true
  }
};

let settings = loadJson(SETTINGS_FILE, defaults);
let mainWindow = null;
let floatWindow = null; // v0.6.4：稳定的悬浮工具条（不再使用透明圆球）
let panelWindow = null; // 历史记录/新增SPU小面板
const FLOAT_DOCK_WIDTH = 142;
const FLOAT_DOCK_HEIGHT = 44;
let tray = null;
let isQuitting = false;
let quitBackupDone = false;
let autoBackupTimer = null;
let activityReminderTimer = null;
let lastRendererState = { store: '', spu: '', normal: '', major: '', completion: '', tab: '', dirty: false };
let saveBoundsTimer = null;
let saveFloatBoundsTimer = null;
let recoveryWriteTimer = null;
let lastRecoveryPayload = '';
let quitApproved = false;
let quitFlowActive = false;

function loadJson(file, fallback) {
  try {
    return { ...fallback, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
  } catch {
    return JSON.parse(JSON.stringify(fallback));
  }
}
function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8');
}
function saveSettings() { writeJson(SETTINGS_FILE, settings); }
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

function applyPendingRestoreSync() {
  if (!fs.existsSync(RESTORE_PENDING)) return;
  try {
    const info = JSON.parse(fs.readFileSync(RESTORE_PENDING, 'utf8'));
    if (info?.archive && fs.existsSync(info.archive)) {
      restoreArchiveSync(info.archive);
    }
  } catch (err) {
    try { fs.writeFileSync(path.join(userDataDir, 'restore-error.log'), String(err?.stack || err), 'utf8'); } catch {}
  } finally {
    try { fs.unlinkSync(RESTORE_PENDING); } catch {}
  }
}

function safeRelative(rel) {
  if (!rel || rel.includes('..') || path.isAbsolute(rel)) throw new Error('非法备份路径');
  return rel.replace(/\\/g, '/');
}
function restoreArchiveSync(archive) {
  const gz = fs.readFileSync(archive);
  const raw = zlib.gunzipSync(gz);
  let off = 0;
  if (!raw.subarray(0, BACKUP_MAGIC.length).equals(BACKUP_MAGIC)) throw new Error('不是有效的 Temu 填价助手备份文件');
  off += BACKUP_MAGIC.length;
  const entries = [];
  while (off + 12 <= raw.length) {
    const pathLen = raw.readUInt32BE(off); off += 4;
    const dataLen = Number(raw.readBigUInt64BE(off)); off += 8;
    if (pathLen === 0) break;
    const rel = safeRelative(raw.subarray(off, off + pathLen).toString('utf8')); off += pathLen;
    const data = raw.subarray(off, off + dataLen); off += dataLen;
    entries.push({ rel, data });
  }
  for (const root of BACKUP_ROOTS) {
    const dest = path.join(userDataDir, root);
    try { fs.rmSync(dest, { recursive: true, force: true }); } catch {}
  }
  for (const e of entries) {
    const dest = path.join(userDataDir, e.rel);
    const resolved = path.resolve(dest);
    if (!resolved.startsWith(path.resolve(userDataDir) + path.sep) && resolved !== path.resolve(userDataDir)) throw new Error('恢复路径越界');
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, e.data);
  }
}

applyPendingRestoreSync();
settings = loadJson(SETTINGS_FILE, defaults);

function migrateLegacyFloatingSystem() {
  const legacyKeys = ['floatOpacity','floatSize','floatIconFit','floatIconScale','floatQuickButtons','floatActionSize','floatPanelOpacity','floatPanelRadius','floatingIconPath'];
  const hadLegacy = legacyKeys.some(k => Object.prototype.hasOwnProperty.call(settings, k));
  if (!hadLegacy) return;
  for (const k of legacyKeys) delete settings[k];
  // v0.6.4 是一次悬浮系统重构：首次迁移时主动显示新工具条，避免继续继承旧版“看不见”的状态。
  settings.showFloatOnStart = true;
  try { fs.unlinkSync(path.join(userDataDir, 'float-window-state.json')); } catch {}
  try {
    for (const name of fs.readdirSync(ASSET_DIR)) {
      if (name.startsWith('floating-icon-') || name.startsWith('floating-icon.')) fs.unlinkSync(path.join(ASSET_DIR, name));
    }
  } catch {}
  saveSettings();
}
migrateLegacyFloatingSystem();

function loadWindowState(file, fallback) {
  const v = loadJson(file, fallback);
  return { x: v.x, y: v.y, width: v.width || fallback.width, height: v.height || fallback.height, maximized: !!v.maximized };
}
function loadBounds(file, fallback) {
  const v = loadJson(file, fallback);
  return { x: v.x, y: v.y, width: v.width || fallback.width, height: v.height || fallback.height };
}
function boundsOnScreen(bounds) {
  const displays = screen.getAllDisplays();
  if (!Number.isFinite(bounds.x) || !Number.isFinite(bounds.y)) return false;
  const needW = Math.min(120, Math.max(24, Number(bounds.width || 0) * 0.45));
  const needH = Math.min(80, Math.max(20, Number(bounds.height || 0) * 0.45));
  return displays.some(d => {
    const a = d.workArea;
    const ix = Math.max(0, Math.min(bounds.x + bounds.width, a.x + a.width) - Math.max(bounds.x, a.x));
    const iy = Math.max(0, Math.min(bounds.y + bounds.height, a.y + a.height) - Math.max(bounds.y, a.y));
    return ix >= needW && iy >= needH;
  });
}
function saveWindowBoundsNow() {
  if (!mainWindow || mainWindow.isDestroyed() || mainWindow.isMinimized()) return;
  const maximized = mainWindow.isMaximized();
  const b = maximized ? mainWindow.getNormalBounds() : mainWindow.getBounds();
  writeJson(WINDOW_FILE, { ...b, maximized });
}
function saveFloatBoundsNow() {
  if (!floatWindow || floatWindow.isDestroyed()) return;
  writeJson(FLOAT_FILE, floatWindow.getBounds());
}
function scheduleSaveBounds() {
  clearTimeout(saveBoundsTimer);
  saveBoundsTimer = setTimeout(saveWindowBoundsNow, 250);
}
function scheduleSaveFloatBounds() {
  clearTimeout(saveFloatBoundsTimer);
  saveFloatBoundsTimer = setTimeout(saveFloatBoundsNow, 250);
}

function createMainWindow() {
  const fallback = { width: 1500, height: 920 };
  const saved = loadWindowState(WINDOW_FILE, fallback);
  const opts = {
    width: clamp(saved.width, 1050, 2600),
    height: clamp(saved.height, 700, 1600),
    minWidth: 980,
    minHeight: 650,
    show: false,
    icon: ICON_ICO,
    title: APP_NAME,
    autoHideMenuBar: true,
    backgroundColor: '#f4f6f9',
    webPreferences: {
      preload: path.join(ROOT, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      nodeIntegrationInSubFrames: true
    }
  };
  if (boundsOnScreen(saved)) { opts.x = saved.x; opts.y = saved.y; }
  mainWindow = new BrowserWindow(opts);
  mainWindow.setAlwaysOnTop(!!settings.alwaysOnTop);
  mainWindow.loadFile(path.join(ROOT, 'app', 'index.html'));
  mainWindow.once('ready-to-show', () => { if (saved.maximized) mainWindow.maximize(); mainWindow.show(); });
  mainWindow.on('focus', () => { if (panelWindow && !panelWindow.isDestroyed() && panelWindow.isVisible()) panelWindow.hide(); });
  mainWindow.on('move', scheduleSaveBounds);
  mainWindow.on('resize', scheduleSaveBounds);
  mainWindow.on('maximize', scheduleSaveBounds);
  mainWindow.on('unmaximize', scheduleSaveBounds);
  mainWindow.on('show', rebuildTrayMenu);
  mainWindow.on('hide', rebuildTrayMenu);
  mainWindow.on('minimize', (e) => {
    if (settings.minimizeToTray && !isQuitting) {
      e.preventDefault();
      mainWindow.hide();
      showTrayBalloonOnce();
    }
  });
  mainWindow.on('close', (e) => {
    if (isQuitting) return;
    e.preventDefault();
    saveWindowBoundsNow();
    if (settings.closeToTray) {
      mainWindow.hide();
      showTrayBalloonOnce();
    } else {
      requestQuit();
    }
  });
  mainWindow.on('closed', () => { mainWindow = null; });
  mainWindow.webContents.on('render-process-gone', (_event, details) => {
    if (isQuitting || details.reason === 'clean-exit') return;
    setTimeout(() => {
      if (!mainWindow || mainWindow.isDestroyed()) createMainWindow();
      else mainWindow.reload();
    }, 700);
  });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
}

let trayBalloonShown = false;
function showTrayBalloonOnce() {
  if (trayBalloonShown || !tray) return;
  trayBalloonShown = true;
  try { tray.displayBalloon({ iconType: 'info', title: APP_NAME, content: '程序仍在托盘运行。单击托盘图标可显示或隐藏主窗口。' }); } catch {}
}

function customAssetUrl(filePath, fallback = '') {
  try {
    const target = filePath && fs.existsSync(filePath) ? filePath : (fallback && fs.existsSync(fallback) ? fallback : '');
    if (!target) return '';
    const stamp = Math.round(fs.statSync(target).mtimeMs || 0);
    return pathToFileURL(target).href + (stamp ? `?v=${stamp}` : '');
  } catch { return ''; }
}
function rendererAssets() {
  return { wallpaperUrl: customAssetUrl(settings.wallpaperPath) };
}
function floatDockMenu() {
  return Menu.buildFromTemplate([
    { label: '回主界面', click: showMainWindow },
    { label: '设置', click: showMainSettings },
    { type: 'separator' },
    { label: '隐藏悬浮工具条', click: () => { if (panelWindow && !panelWindow.isDestroyed()) panelWindow.hide(); if (floatWindow && !floatWindow.isDestroyed()) floatWindow.hide(); rebuildTrayMenu(); } }
  ]);
}
function createFloatWindow(show = true) {
  if (floatWindow && !floatWindow.isDestroyed()) {
    if (show) floatWindow.showInactive();
    return floatWindow;
  }
  const fallback = { width: FLOAT_DOCK_WIDTH, height: FLOAT_DOCK_HEIGHT };
  const saved = loadBounds(FLOAT_FILE, fallback);
  const opts = {
    width: FLOAT_DOCK_WIDTH,
    height: FLOAT_DOCK_HEIGHT,
    show: false,
    frame: false,
    transparent: false,
    resizable: false,
    alwaysOnTop: !!settings.floatAlwaysOnTop,
    skipTaskbar: true,
    hasShadow: true,
    icon: ICON_ICO,
    title: 'Temu填价助手 · 悬浮工具条',
    backgroundColor: '#ffffff',
    webPreferences: {
      preload: path.join(ROOT, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  };
  if (boundsOnScreen({ x:saved.x, y:saved.y, width:FLOAT_DOCK_WIDTH, height:FLOAT_DOCK_HEIGHT })) {
    opts.x = saved.x; opts.y = saved.y;
  } else {
    const a = screen.getPrimaryDisplay().workArea;
    opts.x = a.x + a.width - FLOAT_DOCK_WIDTH - 24;
    opts.y = a.y + Math.round(a.height * 0.28);
  }
  floatWindow = new BrowserWindow(opts);
  const revealFloat = () => {
    if (!show || !floatWindow || floatWindow.isDestroyed()) return;
    floatWindow.showInactive();
    try { floatWindow.moveTop(); } catch {}
  };
  floatWindow.loadFile(path.join(ROOT, 'float-dock.html')).then(revealFloat).catch(err => {
    console.error('悬浮工具条加载失败', err);
    if (floatWindow && !floatWindow.isDestroyed()) floatWindow.destroy();
    floatWindow = null;
  });
  floatWindow.on('move', scheduleSaveFloatBounds);
  floatWindow.on('show', rebuildTrayMenu);
  floatWindow.on('hide', rebuildTrayMenu);
  floatWindow.webContents.on('context-menu', () => floatDockMenu().popup({ window: floatWindow }));
  floatWindow.on('close', (e) => {
    if (!isQuitting) { e.preventDefault(); saveFloatBoundsNow(); floatWindow.hide(); if (panelWindow && !panelWindow.isDestroyed()) panelWindow.hide(); }
  });
  floatWindow.on('closed', () => { floatWindow = null; });
  return floatWindow;
}
function positionPanelNearFloat() {
  if (!panelWindow || panelWindow.isDestroyed()) return;
  const panel = panelWindow.getBounds();
  const dock = floatWindow && !floatWindow.isDestroyed() && floatWindow.isVisible()
    ? floatWindow.getBounds()
    : { x: 80, y: 80, width: FLOAT_DOCK_WIDTH, height: FLOAT_DOCK_HEIGHT };
  const display = screen.getDisplayNearestPoint({ x: dock.x, y: dock.y });
  const a = display.workArea;
  let x = dock.x + dock.width + 10;
  let y = dock.y;
  if (x + panel.width > a.x + a.width) x = dock.x - panel.width - 10;
  x = clamp(x, a.x, a.x + a.width - panel.width);
  y = clamp(y, a.y, a.y + a.height - panel.height);
  panelWindow.setPosition(Math.round(x), Math.round(y), false);
}
function createPanelWindow(show = true) {
  if (panelWindow && !panelWindow.isDestroyed()) {
    if (show) { positionPanelNearFloat(); panelWindow.show(); panelWindow.focus(); }
    return panelWindow;
  }
  panelWindow = new BrowserWindow({
    width: clamp(Number(settings.floatPanelWidth) || 560, 470, 760),
    height: 690,
    minWidth: 440,
    minHeight: 520,
    show: false,
    frame: true,
    autoHideMenuBar: true,
    resizable: true,
    alwaysOnTop: !!settings.floatAlwaysOnTop,
    skipTaskbar: true,
    icon: ICON_ICO,
    title: 'Temu填价助手 · 历史小面板',
    backgroundColor: '#ffffff',
    transparent: false,
    hasShadow: true,
    webPreferences: {
      preload: path.join(ROOT, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  panelWindow.loadFile(path.join(ROOT, 'floating.html'));
  panelWindow.on('close', e => { if (!isQuitting) { e.preventDefault(); panelWindow.hide(); } });
  panelWindow.on('closed', () => { panelWindow = null; });
  panelWindow.once('ready-to-show', () => { positionPanelNearFloat(); if (show) panelWindow.show(); });
  return panelWindow;
}
function toggleHistoryPanel() {
  if (!panelWindow || panelWindow.isDestroyed()) return createPanelWindow(true);
  if (panelWindow.isVisible()) panelWindow.hide(); else { positionPanelNearFloat(); panelWindow.show(); panelWindow.focus(); }
}

function showMainSettings() {
  showMainWindow();
  setTimeout(() => sendMainCommand('openSettings'), 60);
}

function showMainWindow() {
  if (panelWindow && !panelWindow.isDestroyed()) panelWindow.hide();
  if (!mainWindow || mainWindow.isDestroyed()) createMainWindow();
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
  rebuildTrayMenu();
}
function toggleMainWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) return createMainWindow();
  if (mainWindow.isMinimized()) { showMainWindow(); return; }
  if (mainWindow.isVisible()) { mainWindow.hide(); rebuildTrayMenu(); } else showMainWindow();
}
function toggleFloatWindow() {
  if (!floatWindow || floatWindow.isDestroyed()) return createFloatWindow(true);
  if (floatWindow.isVisible()) { floatWindow.hide(); if (panelWindow && !panelWindow.isDestroyed()) panelWindow.hide(); } else floatWindow.showInactive();
  rebuildTrayMenu();
}
function sendMainCommand(command) {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  mainWindow.webContents.send('desktop-command', command);
}
function pushRendererState() {
  if (panelWindow && !panelWindow.isDestroyed()) panelWindow.webContents.send('desktop-state', lastRendererState);
}

function normalizeReminderDays(days) {
  const arr = Array.isArray(days) ? days : [];
  return Array.from(new Set(arr.map(Number).filter(n => Number.isInteger(n) && n >= 0 && n <= 6)));
}
function normalizeReminderTime(v) {
  const m = String(v || '').match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return '09:30';
  const h = clamp(Number(m[1]), 0, 23), min = clamp(Number(m[2]), 0, 59);
  return `${String(h).padStart(2,'0')}:${String(min).padStart(2,'0')}`;
}
function reminderNextAt(now = new Date()) {
  if (settings.activityReminderEnabled === false) return '';
  const days = normalizeReminderDays(settings.activityReminderDays);
  if (!days.length) return '';
  const [hh, mm] = normalizeReminderTime(settings.activityReminderTime).split(':').map(Number);
  for (let offset=0; offset<=7; offset++) {
    const d = new Date(now);
    d.setDate(now.getDate() + offset);
    d.setHours(hh, mm, 0, 0);
    if (days.includes(d.getDay()) && d.getTime() > now.getTime()) return d.toISOString();
  }
  return '';
}
function reminderInfo() {
  return {
    enabled: settings.activityReminderEnabled !== false,
    days: normalizeReminderDays(settings.activityReminderDays),
    time: normalizeReminderTime(settings.activityReminderTime),
    text: String(settings.activityReminderText || '记得报名活动'),
    nextAt: reminderNextAt()
  };
}
function showActivityReminder(body = '') {
  const text = String(body || settings.activityReminderText || '记得报名活动').trim() || '记得报名活动';
  try {
    if (Notification.isSupported()) {
      const note = new Notification({ title: `${APP_NAME} · 活动报名提醒`, body: text, icon: ICON_ICO, silent: false });
      note.on('click', showMainWindow);
      note.show();
      return true;
    }
  } catch {}
  try { if (tray) tray.displayBalloon({ iconType:'info', title:`${APP_NAME} · 活动报名提醒`, content:text }); return true; } catch {}
  return false;
}
function checkActivityReminder() {
  if (settings.activityReminderEnabled === false) return;
  const days = normalizeReminderDays(settings.activityReminderDays);
  if (!days.length) return;
  const now = new Date();
  if (!days.includes(now.getDay())) return;
  const [hh, mm] = normalizeReminderTime(settings.activityReminderTime).split(':').map(Number);
  const scheduled = new Date(now); scheduled.setHours(hh, mm, 0, 0);
  const diff = now.getTime() - scheduled.getTime();
  if (diff < 0 || diff > 10 * 60 * 1000) return;
  const key = `${scheduled.getFullYear()}-${String(scheduled.getMonth()+1).padStart(2,'0')}-${String(scheduled.getDate()).padStart(2,'0')}@${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}`;
  if (settings.activityReminderLastFiredKey === key) return;
  settings.activityReminderLastFiredKey = key;
  saveSettings();
  showActivityReminder();
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('desktop-settings-changed', settings);
}
function setupActivityReminderTimer() {
  if (activityReminderTimer) clearInterval(activityReminderTimer);
  activityReminderTimer = null;
  if (settings.activityReminderEnabled === false) return;
  setTimeout(checkActivityReminder, 1200);
  activityReminderTimer = setInterval(checkActivityReminder, 20 * 1000);
}

function trayTemplate() {
  const storeLabel = lastRendererState.store ? `当前店铺：${lastRendererState.store}` : '当前店铺：—';
  const spuLabel = lastRendererState.spu ? `当前SPU：${lastRendererState.spu}` : '当前SPU：—';
  const mainVisible = !!(mainWindow && !mainWindow.isDestroyed() && mainWindow.isVisible() && !mainWindow.isMinimized());
  const floatVisible = !!(floatWindow && !floatWindow.isDestroyed() && floatWindow.isVisible());
  const filesDataSubmenu = [
    { label: '打开待处理表格文件夹', click: () => shell.openPath(ensureWorkspace().inbox) },
    { label: '打开已处理表格文件夹', click: () => shell.openPath(ensureWorkspace().processed) },
    { label: '打开处理记录文件夹', click: () => shell.openPath(ensureWorkspace().logs) },
    { type: 'separator' },
    { label: '立即备份', click: () => createAutoBackup('manual').then(p => dialog.showMessageBox({ type: 'info', message: '备份完成', detail: p || '' })).catch(showError) },
    { label: '打开备份目录', click: () => { fs.mkdirSync(BACKUP_DIR, { recursive: true }); shell.openPath(BACKUP_DIR); } },
    { label: '导出程序数据…', click: exportProgramData },
    { label: '恢复程序数据…', click: restoreProgramData }
  ];
  if (updateStatusInfo().configured) filesDataSubmenu.push({ type: 'separator' }, { label: '检查更新…', click: checkForUpdates });
  return [
    { label: mainVisible ? '隐藏主窗口' : '显示主窗口', click: toggleMainWindow },
    { label: floatVisible ? '隐藏悬浮工具条' : '显示悬浮工具条', click: toggleFloatWindow },
    { label: '打开 / 隐藏历史小面板', click: toggleHistoryPanel },
    { type: 'separator' },
    { label: storeLabel, enabled: false },
    { label: spuLabel, enabled: false },
    { label: '复制当前SPU', enabled: !!lastRendererState.spu, click: () => lastRendererState.spu && clipboard.writeText(lastRendererState.spu) },
    { label: '下一个SPU', click: () => { showMainWindow(); sendMainCommand('next'); } },
    { type: 'separator' },
    { label: '设置…', click: showMainSettings },
    { label: '文件与数据', submenu: filesDataSubmenu },
    { type: 'separator' },
    { label: '退出程序', click: requestQuit }
  ];
}
function rebuildTrayMenu() {
  if (!tray) return;
  tray.setContextMenu(Menu.buildFromTemplate(trayTemplate()));
  const tip = lastRendererState.store ? `${APP_NAME} · ${lastRendererState.store}` : APP_NAME;
  tray.setToolTip(tip);
}
function createTray() {
  let image = nativeImage.createFromPath(TRAY_PNG);
  if (image.isEmpty()) image = nativeImage.createFromPath(ICON_ICO);
  tray = new Tray(image);
  rebuildTrayMenu();
  tray.on('click', () => toggleMainWindow());
}

function registerGlobalShortcuts() {
  globalShortcut.unregisterAll();
  const map = { ...defaults.shortcuts, ...(settings.shortcuts || {}) };
  const enabled = { ...defaults.shortcutEnabled, ...(settings.shortcutEnabled || {}) };
  const pairs = [
    ['toggleMain', map.toggleMain, toggleMainWindow],
    ['toggleFloat', map.toggleFloat, toggleFloatWindow],
    ['toggleHistoryPanel', map.toggleHistoryPanel, toggleHistoryPanel],
    ['copySpu', map.copySpu, () => { if (lastRendererState.spu) clipboard.writeText(lastRendererState.spu); }],
    ['prevSpu', map.prevSpu, () => { showMainWindow(); sendMainCommand('prev'); }],
    ['nextSpu', map.nextSpu, () => { showMainWindow(); sendMainCommand('next'); }]
  ];
  const failures = [];
  for (const [key, accelerator, fn] of pairs) {
    if (!enabled[key] || !accelerator) continue;
    try { if (!globalShortcut.register(accelerator, fn)) failures.push(accelerator); } catch { failures.push(accelerator); }
  }
  return failures;
}
function applyAutoStart() {
  if (process.platform !== 'win32') return;
  try { app.setLoginItemSettings({ openAtLogin: !!settings.autoStart, path: process.execPath }); } catch {}
}
function updateSettings(patch) {
  settings = { ...settings, ...patch, shortcuts: { ...defaults.shortcuts, ...(settings.shortcuts || {}), ...(patch.shortcuts || {}) }, shortcutEnabled: { ...defaults.shortcutEnabled, ...(settings.shortcutEnabled || {}), ...(patch.shortcutEnabled || {}) } };
  settings.floatPanelWidth = clamp(Number(settings.floatPanelWidth) || 560, 470, 760);
  settings.wallpaperOpacity = clamp(Number(settings.wallpaperOpacity) || 0.18, 0, 0.8);
  settings.wallpaperBlur = clamp(Number(settings.wallpaperBlur) || 0, 0, 30);
  settings.backupIntervalMinutes = clamp(Number(settings.backupIntervalMinutes) || 30, 5, 1440);
  settings.backupKeep = clamp(Number(settings.backupKeep) || 10, 2, 100);
  settings.activitySnapshotKeep = clamp(Number(settings.activitySnapshotKeep) || 20, 1, 100);
  settings.particleCount = clamp(Number(settings.particleCount) || 72, 20, 180);
  settings.particleOpacity = clamp(Number(settings.particleOpacity) || 0.58, 0.1, 1);
  settings.workspaceScanSeconds = clamp(Number(settings.workspaceScanSeconds) || 8, 3, 120);
  settings.activityReminderDays = normalizeReminderDays(settings.activityReminderDays);
  settings.activityReminderTime = normalizeReminderTime(settings.activityReminderTime);
  settings.activityReminderText = String(settings.activityReminderText || '记得报名活动').trim().slice(0, 100) || '记得报名活动';
  saveSettings();
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.setAlwaysOnTop(!!settings.alwaysOnTop);
  if (floatWindow && !floatWindow.isDestroyed()) {
    floatWindow.setAlwaysOnTop(!!settings.floatAlwaysOnTop);
    floatWindow.webContents.send('desktop-settings-changed', settings);
  }
  if (panelWindow && !panelWindow.isDestroyed()) { const b=panelWindow.getBounds(); panelWindow.setAlwaysOnTop(!!settings.floatAlwaysOnTop); panelWindow.setBounds({x:b.x,y:b.y,width:settings.floatPanelWidth,height:b.height}); panelWindow.webContents.send('desktop-settings-changed', settings); }
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('desktop-settings-changed', settings);
  applyAutoStart();
  setupAutoBackupTimer();
  setupActivityReminderTimer();
  registerGlobalShortcuts();
  rebuildTrayMenu();
  return settings;
}


function resetDesktopSettings() {
  const preservedWorkspaceRoot = settings.workspaceRoot || '';
  const preservedReminder = {
    activityReminderEnabled: !!settings.activityReminderEnabled,
    activityReminderDays: normalizeReminderDays(settings.activityReminderDays),
    activityReminderTime: normalizeReminderTime(settings.activityReminderTime),
    activityReminderText: String(settings.activityReminderText || '记得报名活动'),
    activityReminderLastFiredKey: settings.activityReminderLastFiredKey || ''
  };
  settings = { ...JSON.parse(JSON.stringify(defaults)), workspaceRoot: preservedWorkspaceRoot, ...preservedReminder };
  saveSettings();
  return updateSettings({});
}

function walkFiles(rootPath, relRoot, out) {
  if (!fs.existsSync(rootPath)) return;
  const st = fs.statSync(rootPath);
  if (st.isFile()) { out.push({ abs: rootPath, rel: relRoot.replace(/\\/g, '/') }); return; }
  for (const name of fs.readdirSync(rootPath)) {
    const abs = path.join(rootPath, name);
    const rel = path.join(relRoot, name);
    const s = fs.statSync(abs);
    if (s.isDirectory()) walkFiles(abs, rel, out); else if (s.isFile()) out.push({ abs, rel: rel.replace(/\\/g, '/') });
  }
}
async function createBackupArchive(dest) {
  try { await session.defaultSession.flushStorageData(); } catch {}
  const files = [];
  for (const root of BACKUP_ROOTS) walkFiles(path.join(userDataDir, root), root, files);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const gzip = zlib.createGzip({ level: 6 });
  const out = fs.createWriteStream(dest);
  gzip.pipe(out);
  gzip.write(BACKUP_MAGIC);
  for (const f of files) {
    const p = Buffer.from(f.rel, 'utf8');
    const data = fs.readFileSync(f.abs);
    const header = Buffer.alloc(12);
    header.writeUInt32BE(p.length, 0);
    header.writeBigUInt64BE(BigInt(data.length), 4);
    gzip.write(header); gzip.write(p); gzip.write(data);
  }
  const end = Buffer.alloc(12); gzip.write(end); gzip.end();
  await finished(out);
  return dest;
}
function backupName(prefix = 'auto') {
  const d = new Date();
  const s = d.toISOString().replace(/[:.]/g, '-');
  return `${prefix}_${s}.temubak`;
}
async function pruneBackups() {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  const list = fs.readdirSync(BACKUP_DIR).filter(x => x.endsWith('.temubak')).map(name => ({ name, full: path.join(BACKUP_DIR, name), t: fs.statSync(path.join(BACKUP_DIR, name)).mtimeMs })).sort((a,b) => b.t-a.t);
  for (const x of list.slice(settings.backupKeep)) { try { fs.unlinkSync(x.full); } catch {} }
}
async function createAutoBackup(reason = 'auto') {
  if (!settings.autoBackup && reason === 'auto') return null;
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  const dest = path.join(BACKUP_DIR, backupName(reason));
  await createBackupArchive(dest);
  await pruneBackups();
  return dest;
}
function setupAutoBackupTimer() {
  if (autoBackupTimer) clearInterval(autoBackupTimer);
  autoBackupTimer = null;
  if (!settings.autoBackup) return;
  const ms = clamp(Number(settings.backupIntervalMinutes) || 30, 5, 1440) * 60 * 1000;
  autoBackupTimer = setInterval(() => createAutoBackup('auto').catch(() => {}), ms);
}
async function exportProgramData() {
  const owner = mainWindow || null;
  const r = await dialog.showSaveDialog(owner, { title: '导出程序数据', defaultPath: path.join(app.getPath('documents'), `Temu填价助手_程序数据_${new Date().toISOString().slice(0,10)}.temubak`), filters: [{ name: 'Temu填价助手备份', extensions: ['temubak'] }] });
  if (r.canceled || !r.filePath) return;
  try { await createBackupArchive(r.filePath); await dialog.showMessageBox(owner, { type: 'info', message: '程序数据已导出', detail: r.filePath }); } catch (e) { showError(e); }
}
async function restoreProgramData() {
  const owner = mainWindow || null;
  const r = await dialog.showOpenDialog(owner, { title: '恢复程序数据', properties: ['openFile'], filters: [{ name: 'Temu填价助手备份', extensions: ['temubak'] }] });
  if (r.canceled || !r.filePaths[0]) return;
  const confirm = await dialog.showMessageBox(owner, { type: 'warning', buttons: ['取消', '恢复并重启'], defaultId: 0, cancelId: 0, message: '恢复会覆盖当前程序数据', detail: '建议先导出一次当前程序数据作为备份。恢复后程序会自动重启。' });
  if (confirm.response !== 1) return;
  writeJson(RESTORE_PENDING, { archive: r.filePaths[0], requestedAt: Date.now() });
  quitApproved = true;
  isQuitting = true;
  app.relaunch();
  app.exit(0);
}


function updateStatusInfo() {
  try {
    const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'update-config.json'), 'utf8'));
    return { configured: !!String(cfg.manifestUrl || '').trim(), version: APP_VERSION };
  } catch { return { configured: false, version: APP_VERSION }; }
}
async function checkForUpdates() {
  try {
    const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'update-config.json'), 'utf8'));
    if (!cfg.manifestUrl) {
      await dialog.showMessageBox(mainWindow || null, { type: 'info', message: '当前版本：' + APP_VERSION, detail: '在线更新框架已准备好，但还没有配置固定发布地址。后续正式发布后即可启用自动版本检查。' });
      return;
    }
    const res = await fetch(cfg.manifestUrl, { cache: 'no-store' });
    if (!res.ok) throw new Error(`更新服务器返回 ${res.status}`);
    const m = await res.json();
    if (!m.version) throw new Error('更新清单缺少 version');
    const newer = compareVersions(String(m.version), APP_VERSION) > 0;
    if (!newer) {
      await dialog.showMessageBox({ type: 'info', message: '已经是最新版本', detail: `当前版本 ${APP_VERSION}` });
      return;
    }
    const box = await dialog.showMessageBox({ type: 'info', buttons: ['稍后', '打开更新地址'], defaultId: 1, message: `发现新版本 ${m.version}`, detail: m.notes || '' });
    if (box.response === 1 && m.downloadUrl) shell.openExternal(m.downloadUrl);
  } catch (e) { showError(e); }
}
function compareVersions(a, b) {
  const aa = a.split('.').map(x => Number(x) || 0), bb = b.split('.').map(x => Number(x) || 0);
  for (let i=0;i<Math.max(aa.length,bb.length);i++) { const d=(aa[i]||0)-(bb[i]||0); if(d) return d; }
  return 0;
}
function showError(err) {
  dialog.showMessageBox({ type: 'error', message: '操作失败', detail: String(err?.message || err) }).catch(() => {});
}


function safeFilePart(v, fallback='未分类') {
  let s = String(v || '').trim().replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/[. ]+$/g, '');
  return (s || fallback).slice(0, 100);
}
function workspacePaths() {
  const base = settings.workspaceRoot && path.isAbsolute(settings.workspaceRoot) ? settings.workspaceRoot : path.join(app.getPath('documents'), 'Temu填价助手工作区');
  return { root:base, inbox:path.join(base,'01_待处理表格'), processed:path.join(base,'02_已处理表格'), logs:path.join(base,'03_处理记录与备份') };
}
function ensureWorkspace() { const p=workspacePaths(); for(const d of Object.values(p)) fs.mkdirSync(d,{recursive:true}); return p; }
function isArchivedOriginalName(name){return /_原表(?:_\d+)?\.xlsx$/i.test(String(name||''))}
function readWorkspaceLedgerRecords(limit=40){
  const p=ensureWorkspace(),file=path.join(p.logs,'处理记录.jsonl'),out=[];
  let fd=null;
  try{
    if(!fs.existsSync(file))return out;
    const st=fs.statSync(file),size=Math.min(st.size,4194304),start=Math.max(0,st.size-size),buf=Buffer.alloc(size);
    fd=fs.openSync(file,'r');fs.readSync(fd,buf,0,size,start);fs.closeSync(fd);fd=null;
    const lines=buf.toString('utf8').split(/\r?\n/).filter(Boolean);
    for(let i=lines.length-1;i>=0&&out.length<limit;i--){
      try{
        const rec=JSON.parse(lines[i]);
        out.push({at:String(rec.at||''),store:String(rec.store||''),source:String(rec.source||''),output:String(rec.output||''),sourceRenamedTo:String(rec.sourceRenamedTo||''),renameWarning:String(rec.renameWarning||''),stats:rec.stats&&typeof rec.stats==='object'?rec.stats:{}});
      }catch{}
    }
  }catch{if(fd!==null)try{fs.closeSync(fd)}catch{}}
  return out;
}
function readLatestWorkspaceLedger(){return readWorkspaceLedgerRecords(1)[0]||null}
function workspaceTaskSummary(){
  const records=readWorkspaceLedgerRecords(2000),now=new Date(),todayKey=`${now.getFullYear()}-${now.getMonth()+1}-${now.getDate()}`,monthKey=`${now.getFullYear()}-${now.getMonth()+1}`;
  let today=0,month=0;
  for(const r of records){const d=new Date(r.at);if(Number.isNaN(d.getTime()))continue;const dk=`${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`,mk=`${d.getFullYear()}-${d.getMonth()+1}`;if(dk===todayKey)today++;if(mk===monthKey)month++}
  return{todayProcessed:today,monthProcessed:month,recent:records.slice(0,8)};
}
function workspaceInfo() { const p=ensureWorkspace(); let count=0; try{count=fs.readdirSync(p.inbox).filter(n=>/\.xlsx$/i.test(n)&&!n.startsWith('~$')&&!isArchivedOriginalName(n)).length}catch{} return {...p,pendingCount:count,autoScan:settings.workspaceAutoScan!==false,scanSeconds:clamp(Number(settings.workspaceScanSeconds)||8,3,120),lastRecord:readLatestWorkspaceLedger(),taskSummary:workspaceTaskSummary(),reminder:reminderInfo()}; }
async function chooseWorkspaceRoot() { const owner=mainWindow||null; const r=await dialog.showOpenDialog(owner,{title:'选择 Temu 填价助手工作区',properties:['openDirectory','createDirectory']}); if(r.canceled||!r.filePaths[0])return workspaceInfo(); updateSettings({workspaceRoot:r.filePaths[0]}); return workspaceInfo(); }
function assertInboxPath(filePath){const p=ensureWorkspace(),a=path.resolve(p.inbox)+path.sep,b=path.resolve(String(filePath||''));if(!b.startsWith(a))throw new Error('文件不在待处理表格文件夹中');return b;}
function listWorkspaceInputFiles(){const p=ensureWorkspace(),arr=[];for(const name of fs.readdirSync(p.inbox)){if(!/\.xlsx$/i.test(name)||name.startsWith('~$')||isArchivedOriginalName(name))continue;const full=path.join(p.inbox,name);try{const st=fs.statSync(full);if(!st.isFile())continue;arr.push({id:`${full}|${st.size}|${Math.round(st.mtimeMs)}`,name,path:full,size:st.size,mtime:st.mtimeMs})}catch{}}return arr.sort((a,b)=>b.mtime-a.mtime)}
function readWorkspaceInputFile(filePath){const full=assertInboxPath(filePath),st=fs.statSync(full);return{name:path.basename(full),path:full,size:st.size,mtime:st.mtimeMs,base64:fs.readFileSync(full).toString('base64')}}
function uniqueOutputPath(dir,name){const ext=path.extname(name),stem=path.basename(name,ext);let out=path.join(dir,name),i=2;while(fs.existsSync(out))out=path.join(dir,`${stem}_${i++}${ext}`);return out}
function appendWorkspaceLedger(entry){const p=ensureWorkspace();fs.appendFileSync(path.join(p.logs,'处理记录.jsonl'),JSON.stringify(entry)+'\n','utf8')}
function saveProcessedWorkspaceFile(payload={}){
  const p=ensureWorkspace(),store=safeFilePart(payload.store,'未分类店铺'),d=new Date(),day=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`,dir=path.join(p.processed,store,day);
  fs.mkdirSync(dir,{recursive:true});
  let name=safeFilePart(payload.name,'已处理.xlsx'); if(!/\.xlsx$/i.test(name))name+='.xlsx';
  const dest=uniqueOutputPath(dir,name);
  let data=payload.data;
  if(data instanceof ArrayBuffer)data=Buffer.from(new Uint8Array(data));
  else if(ArrayBuffer.isView(data))data=Buffer.from(data.buffer,data.byteOffset,data.byteLength);
  else if(data?.type==='Buffer'&&Array.isArray(data.data))data=Buffer.from(data.data);
  else if(typeof data==='string')data=Buffer.from(data,'base64');
  else if(!Buffer.isBuffer(data))throw new Error('导出数据格式无效');
  fs.writeFileSync(dest,data);

  let sourceOriginal='',sourceRenamedTo='',renameWarning='';
  if(payload.sourcePath){
    try{
      sourceOriginal=assertInboxPath(payload.sourcePath);
      if(fs.existsSync(sourceOriginal)){
        const outputStem=path.basename(dest,path.extname(dest));
        const desired=path.join(path.dirname(sourceOriginal),`${outputStem}_原表.xlsx`);
        sourceRenamedTo=uniqueOutputPath(path.dirname(desired),path.basename(desired));
        fs.renameSync(sourceOriginal,sourceRenamedTo);
      }
    }catch(err){renameWarning=String(err?.message||err)}
  }
  appendWorkspaceLedger({at:new Date().toISOString(),store,source:String(payload.sourceName||''),sourceOriginal,sourceRenamedTo,renameWarning,output:dest,stats:payload.stats&&typeof payload.stats==='object'?payload.stats:{}});
  return{ok:true,path:dest,folder:dir,store,day,sourceOriginal,sourceRenamedTo,renameWarning}
}

async function chooseCustomAsset(kind) {
  if (kind !== 'wallpaper') return null;
  const owner = mainWindow || null;
  const r = await dialog.showOpenDialog(owner, {
    title: '选择页面背景壁纸',
    properties: ['openFile'],
    filters: [{ name: '图片', extensions: ['png','jpg','jpeg','webp','bmp','gif'] }]
  });
  if (r.canceled || !r.filePaths[0]) return null;
  const src = r.filePaths[0];
  const ext = path.extname(src).toLowerCase() || '.png';
  const dest = path.join(ASSET_DIR, `wallpaper-${Date.now()}${ext}`);
  for (const name of fs.readdirSync(ASSET_DIR)) {
    if (name.startsWith('wallpaper-') || name.startsWith('wallpaper.')) { try { fs.unlinkSync(path.join(ASSET_DIR, name)); } catch {} }
  }
  fs.copyFileSync(src, dest);
  updateSettings({ wallpaperPath: dest, wallpaperEnabled: true });
  return { path: dest, url: customAssetUrl(dest) };
}
function resetCustomAsset(kind) {
  if (kind !== 'wallpaper') return rendererAssets();
  const p = settings.wallpaperPath;
  if (p && String(p).startsWith(ASSET_DIR)) { try { fs.unlinkSync(p); } catch {} }
  updateSettings({ wallpaperPath: '', wallpaperEnabled: false });
  return rendererAssets();
}

async function callMainBridge(method, payload = null) {
  if (!mainWindow || mainWindow.isDestroyed()) createMainWindow();
  try { await mainWindow.webContents.executeJavaScript('document.readyState'); } catch {}
  const code = `window.TemuDesktopBridge && window.TemuDesktopBridge[${JSON.stringify(method)}] ? window.TemuDesktopBridge[${JSON.stringify(method)}](${JSON.stringify(payload)}) : null`;
  try { return await mainWindow.webContents.executeJavaScript(code, true); }
  catch (err) { throw new Error('主程序历史数据尚未准备好：' + (err?.message || err)); }
}

ipcMain.handle('desktop:get-workspace-info', () => workspaceInfo());
ipcMain.handle('desktop:choose-workspace-root', () => chooseWorkspaceRoot());
ipcMain.handle('desktop:open-workspace-root', () => shell.openPath(ensureWorkspace().root));
ipcMain.handle('desktop:open-workspace-inbox', () => shell.openPath(ensureWorkspace().inbox));
ipcMain.handle('desktop:open-workspace-processed', () => shell.openPath(ensureWorkspace().processed));
ipcMain.handle('desktop:open-workspace-logs', () => shell.openPath(ensureWorkspace().logs));
ipcMain.handle('desktop:open-workspace-file-location', (_e, filePath) => { const p=ensureWorkspace(),full=path.resolve(String(filePath||'')),base=path.resolve(p.processed)+path.sep;if(!full.startsWith(base))throw new Error('只能打开已处理表格位置');if(fs.existsSync(full))shell.showItemInFolder(full);else shell.openPath(path.dirname(full));return true; });
ipcMain.handle('desktop:workspace-list-files', () => listWorkspaceInputFiles());
ipcMain.handle('desktop:workspace-read-file', (_e, filePath) => readWorkspaceInputFile(filePath));
ipcMain.handle('desktop:workspace-save-processed', (_e, payload) => saveProcessedWorkspaceFile(payload || {}));
ipcMain.handle('desktop:show-main-from-panel', () => { showMainWindow(); if (panelWindow && !panelWindow.isDestroyed()) panelWindow.hide(); return true; });
ipcMain.on('desktop:move-float', (_e, pos) => { if (!floatWindow || floatWindow.isDestroyed() || !pos) return; const b=floatWindow.getBounds(),display=screen.getDisplayNearestPoint({x:Number(pos.x)||b.x,y:Number(pos.y)||b.y}),a=display.workArea; const x=clamp(Math.round(Number(pos.x)||b.x),a.x,a.x+a.width-b.width),y=clamp(Math.round(Number(pos.y)||b.y),a.y,a.y+a.height-b.height); floatWindow.setPosition(x,y,false); scheduleSaveFloatBounds(); });
ipcMain.handle('desktop:get-float-bounds', () => floatWindow && !floatWindow.isDestroyed() ? floatWindow.getBounds() : null);
ipcMain.handle('desktop:get-settings', () => settings);
ipcMain.handle('desktop:get-assets', () => rendererAssets());
ipcMain.handle('desktop:choose-wallpaper', () => chooseCustomAsset('wallpaper'));
ipcMain.handle('desktop:reset-wallpaper', () => resetCustomAsset('wallpaper'));
ipcMain.handle('desktop:hide-history-panel', () => { if (panelWindow && !panelWindow.isDestroyed()) panelWindow.hide(); return true; });
ipcMain.handle('desktop:toggle-history-panel', () => { toggleHistoryPanel(); return true; });
ipcMain.handle('desktop:history-search', (_e, q) => callMainBridge('searchHistory', q));
ipcMain.handle('desktop:history-detail', (_e, spu) => callMainBridge('historyDetail', spu));
ipcMain.handle('desktop:history-add', (_e, payload) => callMainBridge('addHistory', payload));
ipcMain.handle('desktop:history-update', (_e, payload) => callMainBridge('updateHistory', payload));
ipcMain.handle('desktop:history-set-image', (_e, payload) => callMainBridge('setHistoryImage', payload));
ipcMain.handle('desktop:update-settings', (_e, patch) => updateSettings(patch || {}));
ipcMain.handle('desktop:get-state', () => lastRendererState);
ipcMain.handle('desktop:get-recovery', () => loadJson(RECOVERY_FILE, {}));
ipcMain.handle('desktop:open-settings', () => { showMainSettings(); return true; });
ipcMain.handle('desktop:toggle-float', () => { toggleFloatWindow(); return true; });
ipcMain.handle('desktop:show-main', () => { showMainWindow(); return true; });
ipcMain.handle('desktop:hide-float', () => { if (panelWindow && !panelWindow.isDestroyed()) panelWindow.hide(); if (floatWindow && !floatWindow.isDestroyed()) floatWindow.hide(); rebuildTrayMenu(); return true; });
ipcMain.handle('desktop:command', (_e, cmd) => { if (cmd === 'copy') { if (lastRendererState.spu) clipboard.writeText(lastRendererState.spu); } else if (String(cmd||'').startsWith('copyText:')) { clipboard.writeText(String(cmd).slice(9)); } else { showMainWindow(); sendMainCommand(cmd); } return true; });
ipcMain.handle('desktop:export-data', exportProgramData);
ipcMain.handle('desktop:restore-data', restoreProgramData);
ipcMain.handle('desktop:backup-now', () => createAutoBackup('manual'));
ipcMain.handle('desktop:open-backup-dir', () => { fs.mkdirSync(BACKUP_DIR, { recursive: true }); return shell.openPath(BACKUP_DIR); });
ipcMain.handle('desktop:check-updates', checkForUpdates);
ipcMain.handle('desktop:get-update-status', () => updateStatusInfo());
ipcMain.handle('desktop:reset-settings', () => resetDesktopSettings());
ipcMain.handle('desktop:test-activity-reminder', () => showActivityReminder('这是活动报名提醒测试。提醒功能已正常工作。'));
ipcMain.on('desktop-state-update', (_e, state) => {
  if (!state || typeof state !== 'object') return;
  const next = {
    store: String(state.store || ''),
    spu: String(state.spu || ''),
    normal: String(state.normal || ''),
    major: String(state.major || ''),
    completion: String(state.completion || ''),
    tab: String(state.tab || ''),
    dirty: !!state.dirty
  };
  const changed = JSON.stringify(next) !== JSON.stringify(lastRendererState);
  lastRendererState = next;
  if (changed) { pushRendererState(); rebuildTrayMenu(); }
  const payload = JSON.stringify({ ...next, updatedAt: Date.now() });
  if (payload !== lastRecoveryPayload) {
    lastRecoveryPayload = payload;
    clearTimeout(recoveryWriteTimer);
    recoveryWriteTimer = setTimeout(() => { try { writeJson(RECOVERY_FILE, JSON.parse(payload)); } catch {} }, 500);
  }
});


async function requestQuit() {
  if (quitFlowActive || quitApproved) return;
  quitFlowActive = true;
  try {
    if (lastRendererState.dirty && mainWindow && !mainWindow.isDestroyed()) {
      showMainWindow();
      const box = await dialog.showMessageBox(mainWindow, {
        type: 'warning',
        buttons: ['取消', '放弃修改并退出', '保存当前并退出'],
        defaultId: 2,
        cancelId: 0,
        message: '当前SPU有尚未保存的修改',
        detail: '可以先保存当前SPU，也可以放弃这次未保存内容后退出。'
      });
      if (box.response === 0) return;
      if (box.response === 2) {
        let ok = false;
        try { ok = !!(await callMainBridge('saveCurrentDraft')); } catch {}
        if (!ok) {
          await dialog.showMessageBox(mainWindow, { type: 'warning', message: '当前内容无法保存', detail: '请检查普通活动价是否已填写正确，再退出；也可以选择“放弃修改并退出”。' });
          return;
        }
      }
    }
    quitApproved = true;
    isQuitting = true;
    saveWindowBoundsNow(); saveFloatBoundsNow();
    app.quit();
  } finally { quitFlowActive = false; }
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => showMainWindow());
  app.whenReady().then(() => {
    Menu.setApplicationMenu(null);
    createTray();
    createMainWindow();
    if (settings.showFloatOnStart) createFloatWindow(true);
    applyAutoStart();
    registerGlobalShortcuts();
    setupAutoBackupTimer();
    setupActivityReminderTimer();
  });
}

app.on('activate', () => showMainWindow());
app.on('window-all-closed', () => { /* 托盘程序保持运行 */ });
app.on('before-quit', (e) => {
  if (!quitApproved) {
    e.preventDefault();
    requestQuit();
    return;
  }
  isQuitting = true;
  saveWindowBoundsNow(); saveFloatBoundsNow();
  if (settings.autoBackup && !quitBackupDone) {
    e.preventDefault();
    quitBackupDone = true;
    createAutoBackup('quit').catch(() => {}).finally(() => app.exit(0));
  }
});
app.on('will-quit', () => { globalShortcut.unregisterAll(); });
