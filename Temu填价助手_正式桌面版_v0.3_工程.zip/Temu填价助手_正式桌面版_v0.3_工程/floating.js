const $=id=>document.getElementById(id);
function render(s={}){$('spu').textContent='SPU：'+(s.spu||'—');$('store').textContent='店铺：'+(s.store||'—');$('normal').textContent=s.normal||'—';$('major').textContent=s.major||'—';$('completion').textContent=s.completion||'—';}
window.temuDesktop.getState().then(render);
window.temuDesktop.getSettings().then(s=>{$('opacity').value=Math.round((Number(s.floatOpacity)||.94)*100)});
window.temuDesktop.onState(render);
$('copyBtn').onclick=()=>window.temuDesktop.command('copy');
$('prevBtn').onclick=()=>window.temuDesktop.command('prev');
$('nextBtn').onclick=()=>window.temuDesktop.command('next');
$('mainBtn').onclick=()=>window.temuDesktop.showMain();
$('hideBtn').onclick=()=>window.temuDesktop.hideFloat();
let t=null;$('opacity').oninput=e=>{clearTimeout(t);t=setTimeout(()=>window.temuDesktop.setFloatOpacity(Number(e.target.value)/100),120)};
