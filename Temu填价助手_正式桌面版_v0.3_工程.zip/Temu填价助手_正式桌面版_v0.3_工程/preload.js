const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('temuDesktop', {
  getSettings: () => ipcRenderer.invoke('desktop:get-settings'),
  updateSettings: patch => ipcRenderer.invoke('desktop:update-settings', patch),
  getState: () => ipcRenderer.invoke('desktop:get-state'),
  getRecovery: () => ipcRenderer.invoke('desktop:get-recovery'),
  openSettings: () => ipcRenderer.invoke('desktop:open-settings'),
  toggleFloat: () => ipcRenderer.invoke('desktop:toggle-float'),
  showMain: () => ipcRenderer.invoke('desktop:show-main'),
  hideFloat: () => ipcRenderer.invoke('desktop:hide-float'),
  command: cmd => ipcRenderer.invoke('desktop:command', cmd),
  setFloatOpacity: value => ipcRenderer.invoke('desktop:set-float-opacity', value),
  exportData: () => ipcRenderer.invoke('desktop:export-data'),
  restoreData: () => ipcRenderer.invoke('desktop:restore-data'),
  backupNow: () => ipcRenderer.invoke('desktop:backup-now'),
  openBackupDir: () => ipcRenderer.invoke('desktop:open-backup-dir'),
  checkUpdates: () => ipcRenderer.invoke('desktop:check-updates'),
  onState: fn => ipcRenderer.on('desktop-state', (_e, state) => fn(state)),
  onSettingsChanged: fn => ipcRenderer.on('desktop-settings-changed', (_e, settings) => fn(settings))
});

function isMainApp() {
  return /[\\/]app[\\/]index\.html$/i.test(decodeURIComponent(location.pathname || '')) || /\/app\/index\.html$/i.test(location.pathname || '');
}
function activeTabName() {
  const active = document.querySelector('.app-tab.active');
  return active?.textContent?.trim() || '';
}
function currentStore() {
  const sf = document.getElementById('storeFilter');
  if (!sf) return '';
  const opt = sf.options?.[sf.selectedIndex];
  const raw = opt?.textContent || sf.value || '';
  return String(raw).replace(/^店铺：/, '').split('·')[0].trim();
}
function currentSpu() {
  const t = document.getElementById('currentSpu')?.textContent?.trim() || '';
  return t === '-' ? '' : t;
}
function reportMainState() {
  if (!isMainApp()) return;
  const payload = {
    store: currentStore(),
    spu: currentSpu(),
    normal: document.getElementById('normalPrice')?.value || '',
    major: document.getElementById('majorPrice')?.value || '',
    completion: document.getElementById('storeCompletionText')?.textContent?.trim() || '',
    tab: activeTabName()
  };
  ipcRenderer.send('desktop-state-update', payload);
}
function flash(el) {
  if (!el) return;
  const old = el.style.boxShadow;
  el.style.boxShadow = '0 0 0 3px rgba(37,99,235,.32)';
  setTimeout(() => { el.style.boxShadow = old; }, 900);
}
function clickPrevSpu() {
  const items = Array.from(document.querySelectorAll('#spuList .spu-item'));
  const idx = items.findIndex(x => x.classList.contains('active'));
  if (idx > 0) items[idx - 1].click();
}
function handleCommand(cmd) {
  if (!isMainApp()) return;
  if (cmd === 'next') {
    const btn = document.getElementById('saveNext');
    if (btn) { flash(btn); btn.click(); }
  } else if (cmd === 'prev') {
    clickPrevSpu();
  } else if (cmd === 'focus') {
    const el = document.getElementById('currentSpu');
    el?.scrollIntoView({ behavior: 'smooth', block: 'center' }); flash(el);
  }
}
ipcRenderer.on('desktop-command', (_e, cmd) => handleCommand(cmd));

function injectDesktopControls() {
  if (!isMainApp() || document.getElementById('desktopBridgeBar')) return;
  const style = document.createElement('style');
  style.textContent = `
    #desktopBridgeBar{position:fixed;right:14px;bottom:14px;z-index:2500;display:flex;gap:7px;align-items:center;padding:7px 8px;background:rgba(255,255,255,.94);border:1px solid #dbe4ef;border-radius:12px;box-shadow:0 8px 26px rgba(15,23,42,.14);backdrop-filter:blur(8px)}
    #desktopBridgeBar button{height:32px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;color:#334155;font-size:12px;font-weight:700;padding:0 10px;cursor:pointer}
    #desktopBridgeBar button:hover{border-color:#2563eb;color:#2563eb;background:#eff6ff}
    #desktopBridgeBar .desk-dot{width:8px;height:8px;border-radius:50%;background:#22c55e;box-shadow:0 0 0 3px rgba(34,197,94,.12)}
    @media(max-width:700px){#desktopBridgeBar{right:8px;bottom:8px}#desktopBridgeBar button{padding:0 8px}}
  `;
  document.head.appendChild(style);
  const bar = document.createElement('div');
  bar.id = 'desktopBridgeBar';
  bar.innerHTML = '<span class="desk-dot" title="桌面程序已连接"></span><button id="desktopFloatBtn" type="button">悬浮窗</button><button id="desktopSettingsBtn" type="button">桌面设置</button>';
  document.body.appendChild(bar);
  document.getElementById('desktopFloatBtn').addEventListener('click', () => ipcRenderer.invoke('desktop:toggle-float'));
  document.getElementById('desktopSettingsBtn').addEventListener('click', () => ipcRenderer.invoke('desktop:open-settings'));
}

async function attemptRecovery() {
  if (!isMainApp()) return;
  let recovery = {};
  try { recovery = await ipcRenderer.invoke('desktop:get-recovery'); } catch { return; }
  if (!recovery?.spu && !recovery?.store) return;
  let tries = 0;
  const timer = setInterval(() => {
    tries++;
    if (recovery.store) {
      const sf = document.getElementById('storeFilter');
      if (sf && sf.options?.length && sf.value !== recovery.store) {
        const has = Array.from(sf.options).some(o => o.value === recovery.store);
        if (has) { sf.value = recovery.store; sf.dispatchEvent(new Event('change', { bubbles: true })); }
      }
    }
    if (recovery.spu) {
      const item = Array.from(document.querySelectorAll('#spuList .spu-item')).find(x => x.dataset.spu === recovery.spu);
      if (item && !item.classList.contains('active')) item.click();
    }
    if (recovery.normal && document.getElementById('normalPrice') && !document.getElementById('normalPrice').value) document.getElementById('normalPrice').value = recovery.normal;
    if (recovery.major && document.getElementById('majorPrice') && !document.getElementById('majorPrice').value) document.getElementById('majorPrice').value = recovery.major;
    if (tries > 12 || (recovery.spu && currentSpu() === recovery.spu)) clearInterval(timer);
  }, 700);
}

document.addEventListener('DOMContentLoaded', () => {
  if (!isMainApp()) return;
  injectDesktopControls();
  attemptRecovery();
  setInterval(reportMainState, 900);
  reportMainState();
});
