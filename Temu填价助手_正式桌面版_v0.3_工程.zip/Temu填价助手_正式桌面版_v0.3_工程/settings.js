const ids=['closeToTray','minimizeToTray','alwaysOnTop','showFloatOnStart','autoStart','autoBackup'];
let applying=false;
async function load(){const s=await window.temuDesktop.getSettings();applying=true;ids.forEach(id=>document.getElementById(id).checked=!!s[id]);document.getElementById('floatOpacity').value=Math.round((Number(s.floatOpacity)||.94)*100);document.getElementById('backupIntervalMinutes').value=s.backupIntervalMinutes||30;document.getElementById('backupKeep').value=s.backupKeep||10;applying=false;}
async function save(patch){if(applying)return;await window.temuDesktop.updateSettings(patch);document.getElementById('status').textContent='设置已保存';setTimeout(()=>document.getElementById('status').textContent='',1200)}
ids.forEach(id=>document.getElementById(id).addEventListener('change',e=>save({[id]:e.target.checked})));
document.getElementById('floatOpacity').addEventListener('change',e=>save({floatOpacity:Number(e.target.value)/100}));
document.getElementById('backupIntervalMinutes').addEventListener('change',e=>save({backupIntervalMinutes:Number(e.target.value)}));
document.getElementById('backupKeep').addEventListener('change',e=>save({backupKeep:Number(e.target.value)}));
document.getElementById('backupNow').onclick=async()=>{const p=await window.temuDesktop.backupNow();document.getElementById('status').textContent=p?'备份完成：'+p:'已完成'};
document.getElementById('openBackupDir').onclick=()=>window.temuDesktop.openBackupDir();
document.getElementById('exportData').onclick=()=>window.temuDesktop.exportData();
document.getElementById('restoreData').onclick=()=>window.temuDesktop.restoreData();
document.getElementById('checkUpdates').onclick=()=>window.temuDesktop.checkUpdates();
window.temuDesktop.onSettingsChanged(()=>load());load();
