const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const vm = require('vm');

const projectRoot = path.resolve(__dirname, '..');
const mainSource = fs.readFileSync(path.join(projectRoot, 'main.js'), 'utf8');
const start = mainSource.indexOf('function safeFilePart');
const end = mainSource.indexOf('\n\nasync function chooseCustomAsset', start);
assert(start >= 0 && end > start, '无法读取工作区文件生命周期代码');
const lifecycleSource = mainSource.slice(start, end);

function loadLifecycle(workspaceRoot, fsImpl = fs) {
  const context = vm.createContext({
    fs: fsImpl,
    path,
    app: { getPath: () => workspaceRoot },
    settings: { workspaceRoot },
    mainWindow: null,
    Buffer,
    ArrayBuffer,
    process,
    console
  });
  vm.runInContext(lifecycleSource, context, { filename: 'main-workspace-lifecycle.js' });
  return vm.runInContext('({ ensureWorkspace, saveProcessedWorkspaceFiles })', context);
}

function makeSource(api, name, data) {
  const workspace = api.ensureWorkspace();
  const file = path.join(workspace.inbox, name);
  fs.writeFileSync(file, data);
  const stat = fs.statSync(file);
  return { workspace, file, stat };
}

function payloadFor(source, store, outputName, data) {
  return {
    store,
    name: outputName,
    sourceName: path.basename(source.file),
    sourcePath: '',
    sourceSize: source.stat.size,
    sourceLastModified: source.stat.mtimeMs,
    data,
    stats: { updated: 1, deleted: 0, invUpdated: 0, invDeleted: 0, unknown: 0 }
  };
}

function verifySuccess() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'temu-workspace-success-'));
  try {
    const api = loadLifecycle(root);
    const source = makeSource(api, '活动报名.xlsx', Buffer.from('original'));
    const [saved] = api.saveProcessedWorkspaceFiles([
      payloadFor(source, '测试店铺', '测试店铺_0824周一_1200.xlsx', Buffer.from('processed'))
    ]);
    assert.strictEqual(path.dirname(saved.path), path.join(source.workspace.processed, '测试店铺'), '导出文件不应包含日期目录');
    assert(fs.existsSync(saved.path), '导出文件不存在');
    assert(!fs.existsSync(source.file), '原表仍保留旧名称');
    assert(fs.existsSync(saved.sourceRenamedTo), '原表没有按导出文件名改名');
    const ledger = fs.readFileSync(path.join(source.workspace.logs, '处理记录.jsonl'), 'utf8').trim().split(/\r?\n/);
    assert.strictEqual(ledger.length, 1, '成功导出应写入一条处理记录');
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
}

function verifyBatchRollback() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'temu-workspace-rollback-'));
  try {
    let failPath = '';
    let failed = false;
    const fsImpl = Object.create(fs);
    fsImpl.renameSync = (from, to) => {
      if (!failed && path.resolve(from) === path.resolve(failPath)) {
        failed = true;
        throw new Error('模拟原表被占用');
      }
      return fs.renameSync(from, to);
    };
    const api = loadLifecycle(root, fsImpl);
    const first = makeSource(api, '报名1.xlsx', Buffer.from('one'));
    const second = makeSource(api, '报名2.xlsx', Buffer.from('two'));
    failPath = second.file;
    assert.throws(() => api.saveProcessedWorkspaceFiles([
      payloadFor(first, '店铺A', '店铺A_0824周一_1200.xlsx', Buffer.from('new-one')),
      payloadFor(second, '店铺B', '店铺B_0824周一_1200.xlsx', Buffer.from('new-two'))
    ]), /历史未写入/);
    assert(fs.existsSync(first.file), '批量失败后第一个原表未恢复');
    assert(fs.existsSync(second.file), '批量失败后第二个原表不应改名');
    assert(!fs.existsSync(path.join(first.workspace.logs, '处理记录.jsonl')), '批量失败不应写处理记录');
    const outputs = fs.readdirSync(first.workspace.processed, { recursive: true }).filter(name => /\.xlsx$/i.test(String(name)));
    assert.strictEqual(outputs.length, 0, '批量失败后不应保留导出文件');
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
}

verifySuccess();
verifyBatchRollback();
console.log('工作区文件生命周期验证通过');
