const dock=document.getElementById('dock');let down=null,start=null,moved=false;
function applyTheme(st={}){const r=document.documentElement;r.style.setProperty('--blue',st.themePrimary||'#2563eb');r.style.setProperty('--purple',st.themeAccent||'#7c3aed');r.style.setProperty('--surface',st.themeSurface||'#ffffff');r.style.setProperty('--text',st.themeText||'#172033');r.style.setProperty('--line','color-mix(in srgb,var(--text) 15%,var(--surface))')}
window.temuDesktop.getSettings().then(applyTheme).catch(()=>{});window.temuDesktop.onSettingsChanged(applyTheme);
dock.addEventListener('pointerdown',async e=>{if(e.button!==0)return;down={x:e.screenX,y:e.screenY};start=await window.temuDesktop.getFloatBounds();moved=false;try{dock.setPointerCapture(e.pointerId)}catch{}});
dock.addEventListener('pointermove',e=>{if(!down||!start)return;const dx=e.screenX-down.x,dy=e.screenY-down.y;if(Math.abs(dx)+Math.abs(dy)>4)moved=true;if(moved)window.temuDesktop.moveFloat({x:start.x+dx,y:start.y+dy})});
dock.addEventListener('pointerup',e=>{if(!down)return;try{dock.releasePointerCapture(e.pointerId)}catch{};const click=!moved;down=null;start=null;if(click)window.temuDesktop.toggleHistoryPanel()});
