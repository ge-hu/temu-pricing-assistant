$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host '=== Temu填价助手 Windows 构建 ===' -ForegroundColor Cyan
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host '未检测到 Node.js。请先安装 Node.js LTS，然后重新运行。' -ForegroundColor Yellow
  Start-Process 'https://nodejs.org/'
  Read-Host '按 Enter 退出'
  exit 1
}
Write-Host ('Node: ' + (node -v))
Write-Host '安装/更新构建依赖...'
npm install --no-audit --no-fund
Write-Host '生成 Windows x64 便携版 + 安装版...'
npm run dist:win:all
Write-Host '构建完成，正在打开 dist 文件夹。' -ForegroundColor Green
Start-Process (Join-Path $PSScriptRoot 'dist')
Read-Host '按 Enter 退出'
