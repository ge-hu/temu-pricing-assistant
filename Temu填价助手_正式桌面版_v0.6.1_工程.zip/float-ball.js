const icon=document.getElementById('icon'),ball=document.getElementById('ball'),closeFloat=document.getElementById('closeFloat');let down=null,start=null,moved=false;
function applyTheme(st={}){document.documentElement.style.setProperty('--blue',st.themePrimary||'#2563eb');document.documentElement.style.setProperty('--purple',st.themeAccent||'#7c3aed')}
async function refresh(){const [a,st]=await Promise.all([window.temuDesktop.getAssets(),window.temuDesktop.getSettings()]);if(a?.floatingIconUrl)icon.src=a.floatingIconUrl;applyTheme(st||{})}
closeFloat.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation()});
closeFloat.addEventListener('pointerup',e=>{e.preventDefault();e.stopPropagation()});
closeFloat.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();window.temuDesktop.closeFloatingUi()});
ball.addEventListener('pointerdown',async e=>{if(e.button!==0)return;down={x:e.screenX,y:e.screenY};start=await window.temuDesktop.getFloatBounds();moved=false;ball.classList.add('dragging');ball.setPointerCapture(e.pointerId)});
ball.addEventListener('pointermove',e=>{if(!down||!start)return;const dx=e.screenX-down.x,dy=e.screenY-down.y;if(Math.hypot(dx,dy)>4)moved=true;if(moved)window.temuDesktop.moveFloat({x:start.x+dx,y:start.y+dy})});
ball.addEventListener('pointerup',e=>{ball.classList.remove('dragging');try{ball.releasePointerCapture(e.pointerId)}catch{};const click=!moved;down=null;start=null;if(click)window.temuDesktop.toggleHistoryPanel()});
document.addEventListener('contextmenu',e=>{e.preventDefault();window.temuDesktop.openSettings();});window.temuDesktop.onSettingsChanged(st=>{applyTheme(st||{});refresh()});window.temuDesktop.onState(s=>{document.body.title=s?.spu?`当前SPU：${s.spu}`:'Temu填价助手'});refresh();